const routerView = ()=>import( '@/components/routerView')

// text=路由显示名称，icon=图标，type=title标题类型,不可跳转

const quickAccess = [
    {
        path: '/quickAccess',
        name: 'quickAccess',
        meta: {
            text: '快速接入',
            icon: "branches",
			type: 'title'
        },
        component: routerView,
        children: [
			{
				path: '/mobileApp',
				name: 'mobileApp',
				meta: {
					text: '移动端APP应用',
					type: 'title'
				},
				component: () => import('@/views/quickAccess/mobileAPP')
			},
			{
				path: '/weChatApp',
				name: 'weChatApp',
				meta: {
					text: '微信小程序应用',
					type: 'title'
				},
				component: () => import('@/views/quickAccess/wechatAPP'),
			},
			{
				path:'/standardWeb',
				name:'standardWeb',
				meta:{
					text:'标准Web应用',
					type:'title'
				},
				component: () => import('@/views/quickAccess/standardWeb'),
			},
			{
				path:'/afterEndAPI',
				name:'afterEndAPI',
				meta:{
					text:'后端/API服务',
					type:'title'
				},
				component: () => import('@/views/quickAccess/APIServe'),
			}
        ]
	}
];

export default quickAccess

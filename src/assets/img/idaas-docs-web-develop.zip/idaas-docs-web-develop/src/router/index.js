import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

// 基本概念
import conceptual from './conceptual'
// 操作指引
import operational from './operational'
// 应用集成
import applicationIntegration from './applicationIntegration'
// 快速接入
import quickAccess from './quickAccess'
// 草稿
import draft from './draft'

let childrenRouter = [];
childrenRouter.push(...conceptual,...operational,...applicationIntegration,...quickAccess,...draft);

const routes = [
  {
    path: '/',
    name: 'mainView',
    component: resolve => require(['@/components/mainView'], resolve),
    redirect: '/userGroup',
    children: childrenRouter
  },
]

const router = new VueRouter({
  mode: 'history',
  routes
})

export default router

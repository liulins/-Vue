const routerView = ()=>import( '@/components/routerView')

// text=路由显示名称，icon=图标，type=title标题类型,不可跳转

const operational = [
    {
        path: '/guide',
        name: 'guide',
        meta: {
            text: '操作指引',
            icon: "highlight",
			type: 'title'
        },
        component: routerView,
        children: [
			{
				path: '/userManage',
				name: 'userManage',
				meta: {
					text: '用户管理',
					type: 'title',
				},
				component: routerView,
                children: [
					{
						path: '/manageAccount',
						name: 'manageAccount',
						meta: {
							text: '如何管理用户账号',
							type: 'title'
						},
						component: () => import('@/views/optionGuide/userManage/userAccount'),
					},
                    {
                        path: '/manageUserGroup',
                        name: 'manageUserGroup',
                        meta: {
                            text: '如何管理用户组',
                            type: 'title'
                        },
                        component: () => import('@/views/optionGuide/userManage/userGroup'),
                    },
                    {
                        path: '/manageOrganization',
                        name: 'manageOrganization',
                        meta: {
                            text: '如何管理组织机构',
                            type: 'title'
                        },
                        component: () => import('@/views/optionGuide/userManage/organization'),
                    },
                    {
                        path: '/assignPermission',
                        name: 'assignPermission',
                        meta: {
                            text: '如何为用户分配权限',
                            type: 'title'
                        },
                        component: () => import('@/views/optionGuide/userManage/authority'),
                    },
                    {
                        path: '/bindAuthentication',
                        name: 'bindAuthentication',
                        meta: {
                            text: '如何绑定认证设备',
                            type: 'title'
                        },
                        component: () => import('@/views/optionGuide/userManage/bindAuthenticate'),
                    },
                    // {
                    //     path: '/accessHost',
                    //     name: 'accessHost',
                    //     meta: {
                    //         text: '如何访问企业主机',
                    //         type: 'title'
                    //     },
                    //     component: () => import('@/views/optionGuide/userManage/accessHost'),
                    // },
                    {
                        path: '/settingPassword',
                        name: 'settingPassword',
                        meta: {
                            text: '如何设置密码策略',
                            type: 'title'
                        },
                        component: () => import('@/views/optionGuide/userManage/setPassword'),
                    },
                    {
                        path: '/userAttribute',
                        name: 'userAttribute',
                        meta: {
                            text: '用户属性定义',
                            type: 'title'
                        },
                        component: () => import('@/views/optionGuide/userManage/userAttribute'),
                    },

				]
			},
			{
				path: '/applicationMange',
				name: 'applicationMange',
				meta: {
					text: '应用管理',
					type: 'title',
				},
				component: routerView,
				children: [
					{
						path: '/addApplication',
						name: 'addApplication',
						meta: {
							text: '如何添加应用',
							type: 'title',
						},
						component: () => import('@/views/optionGuide/appManage/addApp'),
					},
                    {
						path: '/applicationAuthorizate',
						name: 'applicationAuthorizate',
						meta: {
							text: '应用授权及登录配置',
							type: 'title',
						},
						component: () => import('@/views/optionGuide/appManage/applicateAuthoriza'),
					},
                    {
						path: '/manageSubaccount',
						name: 'manageSubaccount',
						meta: {
							text: '如何管理应用子账号',
							type: 'title',
						},
						component: () => import('@/views/optionGuide/appManage/manageSubaccount'),
					},
                    {
						path: '/achieveSingle',
						name: 'achieveSingle',
						meta: {
							text: '如何实现单点登录',
							type: 'title',
						},
						component: () => import('@/views/optionGuide/appManage/singleLogin'),
					},
                    // {
					// 	path: '/switchLogin',
					// 	name: 'switchLogin',
					// 	meta: {
					// 		text: '如何切换登录风格',
					// 		type: 'title',
					// 	},
					// 	component: () => import('@/views/optionGuide/appManage/loginStyle'),
					// },
				]
			},
			{
				path:'/identityAuthentication',
				name:'identityAuthentication',
				meta:{
					text:'身份认证',
					type: 'title',
				},
				component: routerView,
                children:[
                    {
                        path: '/setLogin',
						name: 'setLogin',
						meta: {
							text: '如何设置登录方式',
							type: 'title',
						},
						component: () => import('@/views/optionGuide/identifyAuthen/loginMethods'),
                    },
                    {
                        path: '/thirdAuthenLogin',
						name: 'thirdAuthenLogin',
						meta: {
							text: '第三方认证源登录',
							type: 'title',
						},
						component: routerView,
                        children:[
                            {
                                path: '/feishuAccess',
                                name: 'feishuAccess',
                                meta: {
                                    text: '飞书认证源接入',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/thirdAuthentica/flyBook'),
                            },
                            {
                                path: '/dingdingAccess',
                                name: 'dingdingAccess',
                                meta: {
                                    text: '钉钉认证源接入',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/thirdAuthentica/dingAuthentica'),
                            },
                            {
                                path: '/enterpriseAccess',
                                name: 'enterpriseAccess',
                                meta: {
                                    text: '企业微信认证源接入',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/thirdAuthentica/enterprise'),
                            },
                            {
                                path: '/LDAPAccess',
                                name: 'LDAPAccess',
                                meta: {
                                    text: 'LDAP认证源接入',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/thirdAuthentica/LDAP'),
                            },
                            {
                                path: '/WindowsAccess',
                                name: 'WindowsAccess',
                                meta: {
                                    text: 'Windows AD认证源接入',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/thirdAuthentica/windowsAD'),
                            },
                            {
                                path: '/WechatAccess',
                                name: 'WechatAccess',
                                meta: {
                                    text: '微信认证源接入',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/thirdAuthentica/wechat'),
                            },
                            {
                                path: '/alipayAccess',
                                name: 'alipayAccess',
                                meta: {
                                    text: '支付宝认证源接入',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/thirdAuthentica/alipay'),
                            },
                            // {
                            //     path: '/configureQQLogin',
                            //     name: 'configureQQLogin',
                            //     meta: {
                            //         text: '配置QQ扫码登录',
                            //         type: 'title',
                            //     },
                            //     component: () => import('@/views/optionGuide/identifyAuthen/thirdAuthentica/QQ'),
                            // },
                        ]
                    },
                    {
                        path: '/MultifactorAuthen',
						name: 'MultifactorAuthen',
						meta: {
							text: '多因素认证MFA',
							type: 'title',
						},
						component: routerView,
                        children:[
                            {
                                path: '/messageAuthentication',
                                name: 'messageAuthentication',
                                meta: {
                                    text: '短信验证码认证',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/MFA/message'),
                            },
                            {
                                path: '/emailAuthentication',
                                name: 'emailAuthentication',
                                meta: {
                                    text: '电子邮箱认证',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/MFA/email'),
                            },
                            {
                                path: '/OTPAuthentication',
                                name: 'OTPAuthentication',
                                meta: {
                                    text: 'OTP动态口令认证',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/MFA/OTPdynamic'),
                            },
                            {
                                path: '/UAFAuthentication',
                                name: 'UAFAuthentication',
                                meta: {
                                    text: 'FIDO UAF指纹/人脸认证',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/MFA/FIDOUAF'),
                            },
                            {
                                path: '/U2FAuthentication',
                                name: 'U2FAuthentication',
                                meta: {
                                    text: 'FIDO U2F认证',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/MFA/FIDOU2F'),
                            },
                            {
                                path: '/USBAuthentication',
                                name: 'USBAuthentication',
                                meta: {
                                    text: 'USBKey认证',
                                    type: 'title',
                                },
                                component: () => import('@/views/optionGuide/identifyAuthen/MFA/USBKey'),
                            }
                        ]
                    },
                ]
			},
			{
				path:'/userInformation',
				name:'userInformation',
				meta:{
					text:'用户信息同步',
					type:'title'
				},
				component: routerView,
                children:[
                    {
                        path:'/LDAPIdentify',
                        name:'LDAPIdentify',
                        meta:{
                            text:'LDAP作为身份源',
                            type:'title'
                        },
                        component: () => import('@/views/optionGuide/userInformation/LDAP'),
                    },
                    {
                        path:'/WindowsIdentify',
                        name:'WindowsIdentify',
                        meta:{
                            text:'Windows AD作为身份源',
                            type:'title'
                        },
                        component: () => import('@/views/optionGuide/userInformation/windowsAD'),
                    },
                ]
			},
			{
				path:'/auditLog',
				name:'auditLog',
				meta:{
					text:'审计日志',
					type:'title'
				},
				component: routerView,
                children:[
                    {
                        path:'/userLog',
                        name:'userLog',
                        meta:{
                            text:'用户行为日志',
                            type:'title'
                        },
                        component: () => import('@/views/optionGuide/auditLog/user'),
                    },
                    {
                        path:'/adminLog',
                        name:'adminLog',
                        meta:{
                            text:'管理员操作日志',
                            type:'title'
                        },
                        component: () => import('@/views/optionGuide/auditLog/admin'),
                    },
                ]
			},
			{
				path:'/businessManage',
				name:'businessManage',
				meta:{
					text:'企业管理',
					type:'title'
				},
				component: routerView,
                children:[
                    {
                        path:'/userdefinedSMS',
                        name:'userdefinedSMS',
                        meta:{
                            text:'自定义短信网关配置',
                            type:'title'
                        },
                        component: () => import('@/views/optionGuide/businessManage/message'),
                    },
                    {
                        path:'/userdefinedEmail',
                        name:'userdefinedEmail',
                        meta:{
                            text:'自定义邮件网关配置',
                            type:'title'
                        },
                        component: () => import('@/views/optionGuide/businessManage/email'),
                    },
                ]
			}
			,
			{
				path:'/adminPermission',
				name:'adminPermission',
				meta:{
					text:'管理员权限如何分配',
					type:'title'
				},
				component: () => import('@/views/optionGuide/ownership'),
			},
			{
				path:'/userService',
				name:'userService',
				meta:{
					text:'用户自助服务',
					type:'title'
				},
				component: () => import('@/views/optionGuide/userServe'),
			}
        ]
	}
];

export default operational

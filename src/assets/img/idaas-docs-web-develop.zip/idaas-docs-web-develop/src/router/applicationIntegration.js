const routerView = ()=>import( '@/components/routerView')

// text=路由显示名称，icon=图标，type=title标题类型,不可跳转

const applicationIntegration = [
    {
        path: '/integration',
        name: 'integration',
        meta: {
            text: '应用集成',
            icon: "radar-chart",
			type: 'title'
        },
        component: routerView,
        children: [
			{
				path: '/aliUser',
				name: 'aliUser',
				meta: {
					text: '阿里云用户SSO',
					type: 'title'
				},
				component: () => import('@/views/applicationIntegration/aliUser')
			},
			{
				path: '/aliRole',
				name: 'aliRole',
				meta: {
					text: '阿里云角色SSO',
					type: 'title'
				},
				component: () => import('@/views/applicationIntegration/aliRole'),
			},
			{
				path:'/tencentUser',
				name:'tencentUser',
				meta:{
					text:'腾讯云用户SSO',
					type:'title'
				},
				component: () => import('@/views/applicationIntegration/tencentUser'),
			},
			{
				path:'/tencentRole',
				name:'tencentRole',
				meta:{
					text:'腾讯云角色SSO',
					type:'title'
				},
				component: () => import('@/views/applicationIntegration/tencentRole'),
			},
			{
				path:'/enjoyPin',
				name:'enjoyPin',
				meta:{
					text:'纷享销客',
					type:'title'
				},
				component: () => import('@/views/applicationIntegration/enjoyPin'),
			},
			// {
			// 	path:'/flyafaortress',
			// 	name:'flyafaortress',
			// 	meta:{
			// 		text:'飞天堡垒机',
			// 		type:'title'
			// 	},
			// 	component: () => import('@/views/applicationIntegration/bastionHost'),
			// }
        ]
	}
];

export default applicationIntegration

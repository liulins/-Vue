const routerView = ()=>import( '@/components/routerView')

// text=路由显示名称，icon=图标，type=title标题类型,不可跳转

const conceptual = [
    {
        path: '/account',
        name: 'account',
        meta: {
            text: '基本概念',
            icon: "read",
			type: 'title'
        },
        component: routerView,
        children: [
			{
				path: '/userGroup',
				name: 'userGroup',
				meta: {
					text: '什么是飞天云信IDaaS',
					type: 'title'
				},
				component: () => import('@/views/conceptual/account')
			},
			{
				path: '/userGroup2',
				name: 'userGroup2',
				meta: {
					text: '什么是账号生命周期管理',
					type: 'title'
				},
				component: () => import('@/views/conceptual/accountLife'),
			},
			{
				path:'/identity',
				name:'identity',
				meta:{
					text:'什么是身份源',
					type:'title'
				},
				component: () => import('@/views/conceptual/identify'),
			},
			{
				path:'/authentication',
				name:'authentication',
				meta:{
					text:'什么是认证源',
					type:'title'
				},
				component: () => import('@/views/conceptual/authenticate'),
			},
			{
				path:'/single',
				name:'single',
				meta:{
					text:'什么是单点登录',
					type:'title'
				},
				component: () => import('@/views/conceptual/single'),
			}
			,
			{
				path:'/multiFactor',
				name:'multiFactor',
				meta:{
					text:'什么是多因素认证',
					type:'title'
				},
				component: () => import('@/views/conceptual/multiFactor'),
			}
			,
			{
				path:'/application',
				name:'application',
				meta:{
					text:'什么是应用',
					type:'title'
				},
				component: () => import('@/views/conceptual/application'),
			}
			// ,
			// {
			// 	path:'/protocol',
			// 	name:'protocol',
			// 	meta:{
			// 		text:'有哪些认证协议',
			// 		type:'title'
			// 	},
			// 	component: () => import('@/views/conceptual/protocol'),
			// }
        ]
	}
];

export default conceptual

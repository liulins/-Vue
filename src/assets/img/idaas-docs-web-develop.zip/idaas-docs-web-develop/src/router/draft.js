const routerView = ()=>import( '@/components/routerView')

// text=路由显示名称，icon=图标，type=title标题类型,不可跳转




const draft = [
    // {
    //     path: '/draft',
    //     name: 'draft',
    //     meta: {
    //         text: '草稿',
    //         icon: "container",
	// 		type: 'title'
    //     },
    //     component: () => import('@/views/conceptual/account'),
	// }
];

export default draft

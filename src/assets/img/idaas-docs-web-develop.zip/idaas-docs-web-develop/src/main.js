import Vue from 'vue'
import App from './App.vue'
import router from './router'
import Antd from 'ant-design-vue';
import 'ant-design-vue/dist/antd.css';
import '@/assets/css/common.scss'
import anchor from '@/components/anchor/index'
import store from './store'
import VueRouter from 'vue-router'

Vue.config.productionTip = false

Vue.use(Antd);
Vue.use(VueRouter);
const originalPush = VueRouter.prototype.push
const originalReplace = VueRouter.prototype.replace
//push
VueRouter.prototype.push = function push(location, onResolve, onReject) {
    if (onResolve || onReject) return originalPush.call(this, location, onResolve, onReject)
    return originalPush.call(this, location).catch(err => err)
}
//replace
VueRouter.prototype.replace = function push(location, onResolve, onReject) {
    if (onResolve || onReject) return originalReplace.call(this, location, onResolve, onReject)
    return originalReplace.call(this, location).catch(err => err)
}

Vue.component('v-anchor', anchor)

new Vue({
  router,
  store,
  render: h => h(App),
  data: {
      eventHub: new Vue()
  }
}).$mount('#app')

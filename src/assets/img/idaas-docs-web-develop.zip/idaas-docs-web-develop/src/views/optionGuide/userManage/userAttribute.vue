<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">用户属性定义</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS为用户设置统一的用户属性。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    飞天云信IDaaS为企业预置了基本属性如用户名、手机号、邮箱等，但企业在管理过程中有时会需要用到更多的扩展属性，此时可以在用户属性定义模块添加扩展属性以满足需求。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 基本属性定义</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp; 在【用户】-【用户属性定义】处可查看并编辑用户属性，这里包含基本属性和扩展属性两种；<br/>
                    1.3 &nbsp; 点击【基本属性】，这里一共定义了23项用户基本属性，并提供修改功能；<br/>
                    <img src="@/assets/img/u1646.png" class="img1" style="margin-bottom:10px;width:95%"/><br/>
                    1.4 &nbsp; 点击操作列-修改，进入修改页面，可对参数进行设置。<br/>
                    <img src="@/assets/img/u1655.png" class="img1" style="margin-top:10px;margin-bottom:10px;"/><br/>
                    参数说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>参数</th>
                                <th>参数说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">属性代码</td>
                                <td>不可修改</td>
                            </tr>
                            <tr>
                                <td>属性名称</td>
                                <td>可修改</td>
                            </tr>
                            <tr>
                                <td>数据类型</td>
                                <td>不可修改</td>
                            </tr>
                            <tr>
                                <td>字段描述</td>
                                <td>属性的描述</td>
                            </tr>
                            <tr>
                                <td>控制台用户详情是否可见</td>
                                <td>开启后，管理员在管理平台的用户详情展示该属性</td>
                            </tr>
                            <tr>
                                <td>用户门户是否可见</td>
                                <td>开启后，用户在用户门户的个人资料可以看到该属性</td>
                            </tr>
                            <tr>
                                <td>用户是否可编辑</td>
                                <td>开启后，用户在用户门户的个人资料可以编辑该属性</td>
                            </tr>
                            <tr>
                                <td>是否唯一字段</td>
                                <td>开启后，当前字段上报的值将进行唯一校验</td>
                            </tr>
                            <tr>
                                <td>是否必填</td>
                                <td>开启后，将进行必填校验</td>
                            </tr>
                            <tr>
                                <td>是否能导出</td>
                                <td>开启后，将允许导出该属性</td>
                            </tr>
                        </tbody>
                    </table>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 扩展属性定义</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;  点击【扩展属性】标签页，可展示当前企业添加的扩展属性列表，支持添加、删除和修改扩展属性。<br/>
                    <img src="@/assets/img/u1647.png" class="img1" style="margin-top:10px;"/><br/>
                    2.2 &nbsp; 点击操作列-修改，进入修改页面。修改页面及参数与基本属性一致；<br/>
                    2.3 &nbsp; 点击操作列-删除，可删除该属性；<br/>
                    2.4 &nbsp; 点击【扩展属性】-【添加属性】，进入添加属性页面，可根据需要自由添加，属性说明同上。<br/>
                    <img src="@/assets/img/u1656.png" class="img1" style="margin-top:20px;margin-bottom:20px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何设置密码策略
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何添加应用
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '基本属性定义'},
                { id: 'd3', title: '扩展属性定义' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/settingPassword"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/addApplication"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
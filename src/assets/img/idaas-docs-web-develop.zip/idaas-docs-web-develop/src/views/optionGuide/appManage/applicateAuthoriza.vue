<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">应用授权及登录配置</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍如何对应用系统进行配置，包括基础配置、登陆配置和访问授权控制。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    飞天云信IDaaS可以对不同的组织机构、用户组、应用、人员等属性按需设置相应的访问权限，也可根据区域策略、时间策略等自动控制权限，实现完整的自动化授权体系。并且可以灵活设置登录方式，提升用户登录体验。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 通用配置</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp; 选择【应用】-【企业应用列表】，右侧页面展示当前企业所有的应用系统；<br/>
                    1.3 &nbsp;  点击应用头像可以进入应用详情，页面提供四个顶部菜单（通用配置、登陆配置、访问授权、子账号），选择【通用配置】标签页，可以修改应用信息。<br/>
                    <img src="@/assets/img/u1906.png" class="img1" style="margin-bottom:10px;width:95%"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 开启多因素认证</p>
                <div class="float"></div>
                <span class="text1">
                    在应用详情页面，选择【登陆配置】标签页，可设置用户登录该应用时的多因素认证方式。此功能提供给某些需要经过二次认证的应用系统，访问时需经过二次认证才可登陆进去，当同时开启多个多因素认证时，用户可自由选择采用哪种认证方式进行认证。<br/>
                    <img src="@/assets/img/u1910.png" class="img1" style="margin-bottom:10px;width:90%"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 访问授权</p>
                <div class="float"></div>
                <span class="text1">
                    在应用详情页面，选择【访问授权】标签页，可为用户/用户组/组织机构设置访问权限。在【认证策略】处可以添加认证策略，通过网段ip、时间等不同策略控制访问。<br/>
                    <img src="@/assets/img/u1907.png" class="img1" style="margin-bottom:10px;width:90%"/><br/>
                    <ul>
                        <li>
                            应用访问控制：控制谁可以访问本应用，允许通过用户/用户组/组织机构来划分权限范围。
                            <img src="@/assets/img/u1908.png" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                        </li>
                        <li>
                            认证策略：可为该应用选择允许/拒绝访问的认证策略（认证策略在【认证】-【认证策略】处添加），可通过网段ip、时间等不同认证策略限制来保护账号安全。
                            <img src="@/assets/img/u1909.png" class="img1" style="margin-bottom:10px;margin-top:10px;width:50%;"/><br/>
                        </li>
                    </ul>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何添加应用
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何管理应用子账号
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '通用配置'},
                { id: 'd3', title: '开启多因素认证' },
                { id: 'd4', title: '访问授权'},
            ],
            prevText:"",
            nextText:"",
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/addApplication"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/manageSubaccount"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">FIDO UAF指纹/人脸认证</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS开启FIDO UAF指纹/人脸认证、用户如何激活绑定FIDO UAF令牌，以及如何使用FIDO UAF指纹/人脸认证登录。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    FIDO (Fast IDentity Online，快速在线身份识别）是一个开放协议,旨在打造一个安全、易用的通用认证接口，解决强认证设备之间的互操作性不足以及用户面临的密码问题（难以创建和记住多个密码）可以能够无缝地在windows、OSX和Linux上使用，一个U2F Key可支持多个服务，一个账号可绑定多个U2F Key，再也不用担心网络钓鱼或盗号的情况。FIDO推出两种用于在线强安全认证的协议：无密码UAF 指纹/人脸认证和双因素认证U2F。FIDO UAF指纹/人脸认证是在默认登陆方式校验后增加生物特征认证，通过指纹或人脸确认后秒速登录，提高安全性和用户体验。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 开启FIDO UAF认证</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    1.2 &nbsp;   在【应用】-【企业应用列表】模块可以查看到所有企业应用，包括用户门户应用系统，以及其他业务应用系统；<br/>
                    1.3 &nbsp;    选择某一应用，进入应用详情，选择【登陆配置】标签页，在多因素认证模块开启「UAF指纹/人脸认证」。<br/>
                        <a-alert
                            class="explain"
                            message="说明"
                            description="1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；
                                        2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；
                                        3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
                            type="info"
                            show-icon
                            close-text="×"
                        />
                    <img src="@/assets/img/u3978.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  用户激活FIDO UAF令牌</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;    若用户未激活UAF令牌，可登录用户门户，进入【账号安全】；<br/>
                    2.2 &nbsp;   点击FIDO UAF令牌后面的【激活】按钮，按照指示进行激活。<br/>
                    <ul>
                        <li style="margin-bottom:0;">
                            步骤一：扫码下载飞天云信令APP，或扫描飞天云信令小程序码进入小程序；
                        </li>
                        <li style="margin-bottom:0;">
                            步骤二：打开飞天云信令APP或小程序，点击“扫一扫”按钮扫描激活二维码，录入人脸/指纹后即可激活成功。
                        </li>
                    </ul>
                    <img src="@/assets/img/u3979.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <!-- 字段描述：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">显示名称</td>
                                <td>通常填写为QQ扫码登录，也可自定义</td>
                            </tr>
                            <tr>
                                <td>APPID</td>
                                <td>在QQ互联管理中心申请的AppId</td>
                            </tr>
                            <tr>
                                <td>APPsecret</td>
                                <td>QQ互联管理中心申请的AppSecret</td>
                            </tr>
                        </tbody>
                    </table> -->
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3.  FIDO UAF认证登录</p>
                <div class="float"></div>
                <span class="text1">
                    用户登录应用时，选择「UAF指纹/人脸认证」认证方式，通过APP或小程序人脸/指纹认证登录。<br/>
                    <img src="@/assets/img/u3954.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：OTP动态口令认证
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：FIDO U2F认证
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '开启FIDO UAF认证'},
                { id: 'd3', title: '用户激活FIDO UAF令牌' },
                { id: 'd4', title: 'FIDO UAF认证登录' },
            ],
            current:0,
            description1:"1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/OTPAuthentication"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/U2FAuthentication"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">用户行为日志</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍介绍IT管理员如何在飞天云信IDaaS管理平台查看用户登陆/登出、以及其他行为日志。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    统一审计功能可以将所有用户以及管理员的的操作日志集中记录并管理和分析，帮助您对用户和管理员行为进行监控和记录，以便于对某次操作进行复盘，对高危行为进行统计，以及事故追责。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">查看用户行为日志</p>
                <div class="float"></div>
                <span class="text1">
                    1. &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    2. &nbsp;   在【审计】-【用户行为日志】模块查看用户在IDaaS平台的所有操作及行为日志，您也可以使用搜索和筛选功能，查看指定的记录。<br/>
                    <img src="@/assets/img/u4602.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    3. &nbsp;    在用户门户系统，用户可自助查看行为日志。在左菜单栏【操作记录】可查看。<br/>
                    <img src="@/assets/img/u4603.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：Windows AD作为身份源
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：管理员操作日志
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '查看用户行为日志'},
            ],
            current:0,
            description1:"1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/WindowsIdentify"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/adminLog"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
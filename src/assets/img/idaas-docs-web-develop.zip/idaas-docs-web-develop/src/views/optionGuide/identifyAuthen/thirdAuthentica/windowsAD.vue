<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">Windows AD认证源接入</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面介绍企业内部AD认证源的接入过程。IDaaS通过ldap协议把认证指向AD域，AD通过认证后，根据AD返回的用户属性与IDaaS用户关联属性做匹配校验，验证通过即可使用AD账号密码登录IDaaS应用。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1" >配置过程</p>
                <span class="text1">
                    <div>
                        <a-steps :current="current" >
                            <a-step title="步骤一" description="IDaaS平台添加AD认证源" />
                            <a-step title="步骤二" description="应用开启AD认证源" />
                            <a-step title="步骤三" description="AD账号密码登陆" />
                        </a-steps>
                        <a-divider />
                    </div>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. IDaaS平台添加AD认证源</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 企业管理员登录飞天云信IDaaS管理平台;
                    <!-- <a href="https://work.weixin.qq.com/wework_admin/">企业微信开发平台</a>； -->
                    <br/>
                    1.2 &nbsp;   登录成功后，在【认证】-【认证源管理】-【添加认证源】找到AD认证源， 点击AD后在配置表单中，填入所需信息；<br/>
                    <img src="@/assets/img/u3057.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <img src="@/assets/img/u3058.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <!-- 字段描述：<br/> -->
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">显示名称</td>
                                <td>通常填写为AD登录，也可自定义</td>
                            </tr>
                            <tr>
                                <td>Windows AD 地址</td>
                                <td>ldap://AD 地址:端口号 例如：ldap://test.idaas.work:88</td>
                            </tr>
                            <tr>
                                <td>Windows AD 端口</td>
                                <td>Windows AD 端口号，例如：88</td>
                            </tr>
                            <tr>
                                <td>BIND DN</td>
                                <td>用于连接Windows AD的用户名,此用户名将用于测试连接结果和搜索用户或用户组。示例：uid=admin,ou=system</td>
                            </tr>
                            <tr>
                                <td>BIND DN 密码</td>
                                <td>用于连接Windows AD的用户密码</td>
                            </tr>
                            <tr>
                                <td>BASE DN</td>
                                <td>定义从哪个目录开始搜索，示例：ou=users，ou=system</td>
                            </tr>
                            <tr>
                                <td>用户查询条件</td>
                                <td>查询条件，该条件结合 bindDN 以及对应的 secret 进行用户查找，用于检索用户的 dn 信息，结合用户密码进行windowsAD认证。支持自定义 filter 表达式，基本形式为：&amp;(objectClass=organizationalPerson)。</td>
                            </tr>
                            <tr>
                                <td>用户名属性名称</td>
                                <td>windowsAD中用户名的属性名称，例：uid</td>
                            </tr>
                        </tbody>
                    </table>
                    1.3 &nbsp;   信息填写完成后，点击【提交】按钮保存。保存成功后，可在认证源列表看见新添加的Windows AD认证源。<br/>
                    <img src="@/assets/img/u3059.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.4 &nbsp;   Windows AD认证源添加后，需要在【应用】下选择用户门户应用，在【登陆配置】标签页下开启Windows AD认证源，只有开启后，用户登录门户系统才可以通过Windows AD认证源一键登录。<br/>
                    <img src="@/assets/img/u3060.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  AD账号登陆</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;   登录用户门户，我们可以在登录页面看到Windows AD登录方式；<br/>
                    <img src="@/assets/img/u3061.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.2 &nbsp;   点击后可通过Windows AD账号+密码登陆。<br/>
                    <img src="@/assets/img/u3062.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：LDAP认证源接入
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：微信认证源接入
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '配置过程' },
                { id: 'd2', title: 'IDaaS平台添加AD认证源'},
                { id: 'd3', title: 'AD账号登陆' },
            ],
            current:0,
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/LDAPAccess"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/WechatAccess"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
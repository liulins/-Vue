<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">企业微信认证源接入</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍将企业微信认证源接入IDaaS中的过程，使用户可以通过企业微信扫码登录各应用系统。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1" >配置过程</p>
                <span class="text1">
                    <div>
                        <a-steps :current="current" >
                            <a-step title="步骤一" description="登陆企业微信开发平台创建应用" />
                            <a-step title="步骤二" description="IDaaS平台添加并启用企业微信认证源" />
                            <a-step title="步骤三" description="企业微信扫码登陆" />
                        </a-steps>
                        <a-divider />
                    </div>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 企业微信开发平台创建应用</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 登录
                    <a href="https://work.weixin.qq.com/wework_admin/">企业微信开发平台</a>；
                    <br/>
                    1.2 &nbsp;   登录成功后，在【我的企业】-【企业信息】中获取到企业的ID;<br/>
                    <img src="@/assets/img/u2735.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.3 &nbsp;   点击【应用管理】-【创建应用】，填写表单信息;<br/>
                    <img src="@/assets/img/u2736.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.4 &nbsp;    创建成功后，点开应用详情，查看 AgentID 和 Secret参数；<br/>
                    <img src="@/assets/img/u2769.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.5 &nbsp;    在应用详情页最下方，设置【企业微信授权登录】，选择web网页应用，配置授权回调域（回调域在IDaaS管理平台【认证源】的企业微信认证源处查看）；<br/>
                    <img src="@/assets/img/u2738.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <img src="@/assets/img/u2772.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.6 &nbsp;    添加网页授权信任域名：在应用详情页，设置【网页授权及 JS-SDK 域名】，域名地址在IDaaS管理平台【认证源】的企业微信认证源处查看。<br/>
                    <img src="@/assets/img/u2770.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  IDaaS平台添加并启用企业微信认证源</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;   企业管理员登录飞天云信IDaaS管理平台;<br/>
                    2.2 &nbsp;   登录成功后，在【认证】-【认证源管理】-【添加认证源】找到企业微信， 点击企业微信，在配置表单中，填入所需信息；<br/>
                    <img src="@/assets/img/u2771.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    字段描述：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">显示名称</td>
                                <td>通常填写为企业微信扫码登录，也可自定义</td>
                            </tr>
                            <tr>
                                <td>企业微信的企业ID</td>
                                <td>企业微信的企业ID</td>
                            </tr>
                            <tr>
                                <td>企业微信应用的AgentId</td>
                                <td>企业微信应用的AgentId，在应用管理处查看</td>
                            </tr>
                            <tr>
                                <td>企业微信应用的Secret</td>
                                <td>企业微信应用的 Secret，在应用管理处查看</td>
                            </tr>
                        </tbody>
                    </table>
                    
                    2.3 &nbsp;   信息填写完成后，点击【创建】按钮保存。保存成功后，可在认证源列表看见新添加的企业微信认证源。<br/>
                    <img src="@/assets/img/u2773.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.4 &nbsp;    企业微信认证源添加后，需要在【应用】下选择用户门户应用，在【登陆配置】标签页下开启企业微信认证源，只有开启后，用户登录门户系统才可以通过企业微信认证源一键登录。<br/>
                    <img src="@/assets/img/u2774.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 企业微信扫码登陆</p>
                <div class="float"></div>
                <span class="text1">
                    登录用户门户，可以在登录页面看到企业微信登录方式，选择后弹出企业微信二维码，扫码后即可登录。
                    <br/>
                    注：第一次扫码登陆的时候，需要与用户进行绑定，绑定之后再次用企业微信扫码登陆时可直接登录，无需绑定。
                    <img src="@/assets/img/u2775.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：钉钉认证源接入
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：LDAP认证源接入
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '配置过程' },
                { id: 'd2', title: '企业微信开发平台创建应用'},
                { id: 'd3', title: 'IDaaS平台添加并启用企业微信认证源' },
                { id: 'd4', title: '企业微信扫码登陆'},
            ],
            current:0,
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/dingdingAccess"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/LDAPAccess"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
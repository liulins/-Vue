<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何绑定认证设备</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍介绍IT管理员如何在飞天云信IDaaS管理平台为用户绑定/解绑认证设备（令牌），以及对认证设备信息统一管理。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    该模块可统一管理维护用户所有已绑定的令牌列表，包含OTP硬件令牌、OTP手机令牌、FIDO设备、USBKey、证书等。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 查看/绑定认证设备</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp;在【用户】-【用户列表】查看所有用户，点击用户操作列的编辑按钮可查看用户详情，点击「认证设备」标签页，可以查看该用户已绑定的所有认证设备（令牌）。
                    <img src="@/assets/img/u1247.png" class="img1" style="margin-top:10px;margin-bottom:20px;"/><br/>
                    1.3 &nbsp;为用户绑定令牌：点击【绑定设备】按钮，在弹出的输入框输入令牌序列号去绑定令牌；<br/>
                    1.4  &nbsp; 也可在【认证】-【认证设备】处查看所有类型的认证设备，及其绑定情况，可在操作列进行解绑/删除/锁定操作。<br/>
                    <img src="@/assets/img/u1252.png" class="img1" style="margin-top:10px;margin-bottom:20px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 开启硬件令牌多因素认证</p>
                <div class="float"></div>
                <span class="text1">
                    为用户绑定好认证设备后，需开启该多因素认证方式。在【应用】-【企业应用列表】处选择某一应用，点击应用图标进入应用详情，选择【登陆配置】标签页，在多因素认证模块开启对应的硬件令牌多因素认证方式。
                </span>
                <img src="@/assets/img/u1249.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 用户通过认证设备登录</p>
                <span class="text1">
                    用户登录应用时，选择该硬件令牌方式登录，根据该令牌特性进行操作（按键或USB设备插入等），认证通过后登录成功。<br/>
                </span>
                <img src="@/assets/img/u1250.jpg" class="img1" style="margin-top:10px;"/>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何为用户分配权限
                 </a>
                 <!-- <a href="##" style="float:right;" @click="next">
                     下一篇：如何访问企业主机
                    <a-icon type="arrow-right" />
                 </a> -->
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何设置密码策略
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '查看/绑定认证设备'},
                { id: 'd3', title: '开启硬件令牌多因素认证' },
                { id: 'd4', title: '用户通过认证设备登录' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/assignPermission"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    // path:"/accessHost"
                    path:"/settingPassword"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
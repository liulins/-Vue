<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">邮箱验证码认证</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS开启邮箱验证码认证，以及用户如何使用邮箱验证码进行认证登录。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    在默认登陆方式校验后增加邮箱验证码验证身份，再次提升账号安全。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 开启邮箱验证码认证</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    1.2 &nbsp;   在【应用】-【企业应用列表】模块可以查看到所有企业应用，包括用户门户应用系统，以及其他业务系统应用；<br/>
                    1.3 &nbsp;   选择某一应用，进入应用详情，选择【登陆配置】标签页，在多因素认证模块开启「电子邮箱验证」。<br/>
                        <a-alert
                            class="explain"
                            message="说明"
                            description="1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；
                                        2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；
                                        3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
                            type="info"
                            show-icon
                            close-text="×"
                        />
                    <img src="@/assets/img/u3746.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  用户自助绑定/修改邮箱</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;    若用户需要未绑定邮箱，或需要修改绑定的邮箱时，可以登录用户门户，进入【账号安全】；<br/>
                    2.2 &nbsp;   点击绑定邮箱后面的【绑定/修改】按钮，按照指示进行绑定/修改。<br/>
                    <img src="@/assets/img/u3747.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <!-- 字段描述：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">显示名称</td>
                                <td>通常填写为QQ扫码登录，也可自定义</td>
                            </tr>
                            <tr>
                                <td>APPID</td>
                                <td>在QQ互联管理中心申请的AppId</td>
                            </tr>
                            <tr>
                                <td>APPsecret</td>
                                <td>QQ互联管理中心申请的AppSecret</td>
                            </tr>
                        </tbody>
                    </table> -->
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3.  邮箱验证码登录</p>
                <div class="float"></div>
                <span class="text1">
                    用户登录应用时，选择电子邮箱验证，点击获取验证码，并输入正确的验证码即可完成基于邮箱的 MFA 验证流程。
                    <br/>
                    <img src="@/assets/img/u3741.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：短信验证码认证
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：OTP动态口令认证
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '开启邮箱验证码认证'},
                { id: 'd3', title: '用户自助绑定/修改邮箱' },
                { id: 'd4', title: '邮箱验证码登录' },
            ],
            current:0,
            description1:"1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/messageAuthentication"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/OTPAuthentication"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
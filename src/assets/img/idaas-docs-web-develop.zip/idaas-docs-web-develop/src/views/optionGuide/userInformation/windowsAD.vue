<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">Windows AD作为身份源</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                IDaaS 可通过企业内部Windows AD拉取用户信息，本页面主要介绍AD作为身份源的同步过程。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1" >配置过程</p>
                <span class="text1">
                    <div>
                        <a-steps :current="current" >
                            <a-step title="步骤一" description="IDaaS平台添加AD身份源" />
                            <a-step title="步骤二" description="AD数据同步到的IDaaS" />
                            <a-step title="步骤三" description="同步记录查看" />
                        </a-steps>
                        <a-divider />
                    </div>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. IDaaS平台添加AD身份源</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 企业管理员登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    1.2 &nbsp;   登录成功后，在【用户】-【身份源列表】-【创建身份源】找到AD， 点击AD，在配置表单中，填入所需信息；<br/>
                    <img src="@/assets/img/u4499.png" class="img1" style="margin-bottom:10px;margin-top:15px;width:60%;"/><br/>
                    <ul>
                        <li>
                             配置信息：填写企Windows AD 的配置信息，填写完成后，点击【测试连通】，提示“校验成功”表明连接正常。
                             <img src="@/assets/img/u4505.png" class="img1" style="margin-bottom:10px;margin-top:15px;width:70%;"/><br/>
                             <table class="fontField">
                                <thead>
                                    <tr>
                                        <th>字段</th>
                                        <th>字段说明</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td style="width: 300px;">同步名称</td>
                                        <td>通常填写为WindowsAD身份源，也可自定义</td>
                                    </tr>
                                    <tr>
                                        <td>WindowsAD地址</td>
                                        <td>WindowsAD 服务器的地址，如：ldap://dc.fabrikam.com</td>
                                    </tr>
                                    <tr>
                                        <td>WindowsAD端口</td>
                                        <td>WindowsAD 端口号，例如：88</td>
                                    </tr>
                                    <tr>
                                        <td>BIND DN</td>
                                        <td>用于连接WindowsAD的用户名,此用户名将用于测试连接结果和搜索用户或用户组。示例：uid=admin,ou=systm</td>
                                    </tr>
                                    <tr>
                                        <td>BIND DN 密码</td>
                                        <td>用于连接WindowsAD的密码</td>
                                    </tr>
                                    <tr>
                                        <td>BASE DN</td>
                                        <td>定义从哪个目录开始搜索，示例：ou=users，ou=system</td>
                                    </tr>
                                    <tr>
                                        <td>用户查询条件</td>
                                        <td>定义查询用户对象的条件，符合这个条件的entry将被视为用户导入到本平台。示例：(|(objectClass=organizationalPerson)(objectClass=person))。</td>
                                    </tr>
                                    <tr>
                                        <td>部门查询条件</td>
                                        <td>定义查询部门对象的条件，符合这个条件的entry将被视为部门导入到本平台。示例：(|(objectClass=organization)(objectClass=organizationalUnit)(objectClass=domain))。</td>
                                    </tr>
                                </tbody>
                            </table>
                        </li>
                        <li>
                            用户同步字段映射：根据实际情况填写映射信息，也可根据实际需要的属性值添加映射。
                            <img src="@/assets/img/u4506.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                        </li>
                        <li>
                             同步信息：可选择手动同步或定时同步。<br/>
                            <img src="@/assets/img/u4349.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                        </li>
                    </ul>
                     1.3 &nbsp;  信息填写完成后，点击【提交】按钮保存。保存成功后，可在认证源列表看见新添加的LDAP认证源。<br/>
                    <img src="@/assets/img/u4507.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  AD数据同步到IDaaS</p>
                <div class="float"></div>
                <span class="text1">
                    点击【立即同步】即可开始同步，状态变为同步中，待同步状态变更为“同步完成”，即表示已经将LDAP数据同步到IDaaS。此时查看用户列表和组织机构，可以看到用户信息以及组织机构有更新；<br/>
                    <img src="@/assets/img/u4305.png" class="img1" style="margin-bottom:10px;margin-top:15px;width:70%;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 同步记录查看</p>
                <div class="float"></div>
                <span class="text1">
                    3.1 &nbsp;  点击身份源“+”-操作-详情，可查看历史同步记录，每一次执行生成一条记录；<br/>
                    <img src="@/assets/img/u4307.png" class="img1" style="margin-bottom:10px;margin-top:15px;width:70%;"/><br/>
                    3.2 &nbsp;   点击详情可查看每次同步操作后，具体的用户及组织机构同步情况。<br/>
                    <img src="@/assets/img/u4309.png" class="img1" style="margin-bottom:10px;margin-top:15px;width:70%;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：LDAP作为身份源
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：用户行为日志
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '配置过程' },
                { id: 'd2', title: 'IDaaS平台添加AD身份源'},
                { id: 'd3', title: 'AD数据同步到IDaaS' },
                { id: 'd4', title: '同步记录查看'},
            ],
            current:0,
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/LDAPIdentify"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/userLog"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
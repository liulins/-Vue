<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何设置密码策略</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS为用户设置统一的密码策略。您可以设置相应的密码复杂度、相应的锁定解锁策略，还可以设置是否允许与历史密码重复等高级策略。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    可根据企业安全标准，设置统一的密码安全策略，包括密码强度设置、登陆安全设置等，全面保护守护您的账号安全。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 密码强度设置</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp;在【用户】-【密码安全策略】处为用户设置统一的密码安全策略；<br/>
                    1.3 &nbsp;点击【密码强度设置】的【修改】按钮，进入设置页面修改参数。<br/>
                    <img src="@/assets/img/u1515.png" class="img1" style="margin-top:10px;margin-bottom:20px;"/><br/>
                    参数说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>参数</th>
                                <th>参数说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">密码长度</td>
                                <td>支持选择区间，最小长度6，最大长度24</td>
                            </tr>
                            <tr>
                                <td>密码复杂度</td>
                                <td>单选，选择密码包含数字、大小写字母及特殊字符的组合搭配</td>
                            </tr>
                            <tr>
                                <td>字符校验</td>
                                <td>开启后限制字符的重复个数，重复字符数不超过(介于1~10之间)</td>
                            </tr>
                            <tr>
                                <td>密码包含用户信息检查</td>
                                <td>开启后不允许密码中包含用户的用户名、手机号、邮箱前缀</td>
                            </tr>
                        </tbody>
                    </table>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 登录安全设置</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;  点击【登录安全设置】，进入设置页面去修改参数。<br/>
                    <img src="@/assets/img/u1152.png" class="img1" style="margin-top:10px;margin-bottom:20px;"/><br/>
                    参数说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>参数</th>
                                <th>参数说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">账号临时锁定</td>
                                <td>连续登录失败次数限制，介于1~10之间</td>
                            </tr>
                            <tr>
                                <td>账号解锁时间</td>
                                <td>账号锁定后自动解锁时间，介于1~1440分钟之间</td>
                            </tr>
                            <tr>
                                <td>账号永久锁定</td>
                                <td>解锁后，连续无效登录次数后永久锁定账号，介于1~10之间</td>
                            </tr>
                            <tr>
                                <td>不活跃锁定</td>
                                <td>用户在规定时间段内不登录将永久锁定，介于1~365之间</td>
                            </tr>
                            <tr>
                                <td>新用户不登录锁定</td>
                                <td>新用户在规定时间段内未登录将永久锁定，介于1~365之间</td>
                            </tr>
                        </tbody>
                    </table>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 高级设置</p>
                <span class="text1">
                    3.1 &nbsp;  点击【登录安全设置】，进入设置页面。<br/>
                    <img src="@/assets/img/u1524.png" class="img1" style="margin-top:10px;margin-bottom:20px;"/><br/>
                    参数说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>参数</th>
                                <th>参数说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">密码倒写检查</td>
                                <td>开启检查后，密码不能使用用户名倒写</td>
                            </tr>
                            <tr>
                                <td>历史密码检查</td>
                                <td>开启检查后，系统记录历史密码，确保旧密码不被连续使用，1-10次之间</td>
                            </tr>
                            <tr>
                                <td>密码过期检查</td>
                                <td>开启后，可设置密码失效时长和密码过期提醒</td>
                            </tr>
                        </tbody>
                    </table>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <!-- <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何访问企业主机
                 </a> -->
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何绑定认证设备
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：用户属性定义
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '密码强度设置'},
                { id: 'd3', title: '登录安全设置' },
                { id: 'd4', title: '高级设置' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    // path:"/accessHost"
                    path:"/bindAuthentication"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/userAttribute"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
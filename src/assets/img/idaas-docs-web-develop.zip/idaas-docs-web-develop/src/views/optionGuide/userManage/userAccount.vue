<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <!-- <div ref="anchorRef" class="anchor-content">
            <div class="title">飞天云信IDaaS介绍</div>
            <div id="d1" class="text">d1    身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d2" class="text">d2     身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d3" class="text">d3   身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d4" class="text">d4   身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d5" class="text">d5   身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d6" class="text"> d6身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
        </div> -->
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何管理用户账号</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS对用户账号进行统一管理，具体包括添加用户、查看/编辑用户信息、修改密码、管理用户账号状态（启用/禁用账户、删除账户等）。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    随着公司的发展，企业内部人员数量不断增加，人员的入职、离职、调岗等场景复杂多变，通过飞天云信IDaaS用户账号管理功能可以将所有用户（员工）的账号信息集中维护，统一管理，解决了企业管理成本高，投入大的问题。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 添加用户</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp;  在左侧菜单栏【用户】-【用户列表】的右侧页面，点击【创建用户】按钮去添加用户，在弹出的输入框填写用户基本信息，最后可以勾选是否强制要求用户改密，然后单击【保存】，即可添加成功。若勾选强制改密，则用户首次登陆用户门户后需要修改密码。
                </span>
                <img src="@/assets/img/u809.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 查看用户详情</p>
                <div class="float"></div>
                <span class="text1">
                    用户添加成功后，点击用户操作列的
                    <img src="@/assets/img/u585.png"/>
                    按钮或点击用户名，可查看用户详情信息。
                    <ul>
                        <li style="margin-bottom:0;margin-top:10px;">
                              用户信息：可查看/编辑当前用户的基本个人信息，和用户加入的分组信息；
                        </li>
                        <li style="margin-bottom:0;">
                            授权管理：可查看当前用户已授权访问的应用系统，并可修改授权信息；
                        </li>
                        <li style="margin-bottom:0;">
                            子账号：当前用户创建的应用子账户，可通过子账号登陆对应的应用系统；
                        </li>
                        <li style="margin-bottom:0;">
                             访问记录：当前用户登录/退出用户门户，以及登陆其他业务应用系统的记录；
                        </li>
                        <li style="margin-bottom:0;">
                            认证设备：可查看该用户所有已绑定的令牌信息，并可执行绑定解绑等操作；
                        </li>
                        <li style="margin-bottom:0;">
                             FIDO U2F硬件令牌：通过FIDO U2F手持式硬件令牌进行身份认证，提升账号信息安全
                        </li>
                        <li style="margin-bottom:0;">
                            企业主机：可查看该用户有权访问的主机列表，并可执行添加、删除主机等操作。
                        </li>
                    </ul> 
                    <img src="@/assets/img/u805.png" class="img1" style="margin-top:10px;"/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 编辑用户信息</p>
                <span class="text1">
                    点击【编辑信息】按钮可编辑用户信息，编辑完成后单击【保存】即可编辑成功。
                </span>
                <img src="@/assets/img/u806.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d5" class="title1">
                <p class="title1_1">4. 修改密码</p>
                <span class="text1">
                    点击用户详情中操作列的【修改密码】按钮，在弹出的会话框中可为该用户生成新的密码。
                </span>
                <img src="@/assets/img/u807.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d6" class="title1">
                <p class="title1_1">5. 管理用户账号状态</p>
                <div class="float"></div>
                <span class="text1">
                    可对用户账号状态进行设置，包括账号锁定、账号删除，以及强制下线。
                    <ul>
                        <li style="margin-bottom:0;margin-top:10px;">
                                锁定账号：点击用户列表操作列的
                                <img src="@/assets/img/u803.png"/>
                                按钮可对用户账号进行锁定。账号锁定后，保留应用授权关系，以及部门关系，但该账号将无法登录任何系统，管理员解锁后可恢复正常使用；
                        </li>
                        <li style="margin-bottom:0;">
                             删除账号：点击用户列表操作列的
                             <img src="@/assets/img/u804.png"/>
                             按钮，可删除用户账号，删除后该账号将取消应用授权关系以及组织机构关系，从用户列表删除，用户也将无法登陆任何系统；
                        </li>
                        <li style="margin-bottom:0;">
                            强制下线：点击用户头像进入用户详情，点击操作列的【强制下线】按钮即可实现账号单次强制下线。
                        </li>
                    </ul> 
                    <img src="@/assets/img/u802.png" class="img1" style="margin-top:10px;"/>
                    <img src="@/assets/img/u808.png" class="img1" style="margin-top:10px;"/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <!-- <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：有哪些认证协议
                 </a> -->
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：什么是应用
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何管理用户组
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            // anchorList: [
            //     { id: 'd1', title: '标题1' },
            //     { id: 'd2', title: '标题2', children: [
            //         { id: 'd3', title: '标题2-1', children: [
            //             { id: 'd4', title: '标题2-1-1' }
            //         ]},
            //     ]},
            //     { id: 'd4', title: '标题4' },
            //     { id: 'd5', title: '标题5' },
            //     { id: 'd6', title: '标题6' },
            // ]
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '添加用户'},
                { id: 'd3', title: '查看用户详情' },
                { id: 'd4', title: '编辑用户信息' },
                { id: 'd5', title: '修改密码' },
                { id: 'd6', title: '管理用户账号状态' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    // path:"/protocol"
                    path:"/application"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/manageUserGroup"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
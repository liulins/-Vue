<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">支付宝认证源接入</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍将支付宝认证源接入IDaaS中的过程，使用户可以通过支付宝扫码登录各应用系统。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1" >配置过程</p>
                <span class="text1">
                    <div>
                        <a-steps :current="current" >
                            <a-step title="步骤一" description="登陆支付宝开放平台创建应用" />
                            <a-step title="步骤二" description="IDaaS平台添加并启用企支付宝认证源" />
                            <a-step title="步骤三" description="支付宝扫码登陆" />
                        </a-steps>
                        <a-divider />
                    </div>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 支付宝开放平台创建应用</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 登录
                    <a href="https://open.alipay.com/">支付宝开放平台</a>；
                    <br/>
                    1.2 &nbsp;   登录成功后，在控制台中，选择网页&移动应用标签，点击【立即创建】， 填写表单信息，其中网址URL为IDaaS回调地址；<br/>
                    <img src="@/assets/img/u3315.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <img src="@/assets/img/u3316.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.3 &nbsp;   创建成功后，为应用添加获取会员信息和第三方应用授权的能力；<br/>
                    <img src="@/assets/img/u3318.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.4 &nbsp;   在
                     <a href="https://miniu.alipay.com/keytool/create">支付宝在线密钥生成器</a> 生成一对应用公钥和私钥，保存在本地（密钥格式一定要选择 PKCS1）；
                     <br/>
                     <span style="color:#E75F70;">*应用私钥对应IDaaS平台支付宝认证源私钥属性，应用公钥对应支付宝开放平台公钥字符属性！</span>
                    <img src="@/assets/img/u3320.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.5 &nbsp;   设置接口加签方式， 将应用公钥填入【公钥字符】中，点击保存；<br/>
                    <img src="@/assets/img/u3325.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.6 &nbsp;   设置回调地址，回调地址即支付宝授权后回调IDaaS地址，在IDaaS管理平台【认证源】的支付宝认证源处查看；<br/>
                    <img src="@/assets/img/u3328.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <img src="@/assets/img/u3376.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.7 &nbsp;   获取应用的AppId 和 AlipayPID 参数保存到本地，并提交审核；
                    <br/>
                    AppID（应用 ID）：在
                     <a href="https://open.alipay.com/dev/workspace">管理中心 - 我的应用列表</a> 可以获取到；
                     <br/>
                     AlipayPID（支付宝主账号 ID）：在
                     <a href="https://openhome.alipay.com/dev/workspace/account-center/main-account-manage">账号中心 - 主账号管理</a> 页面可以获取到。
                    <img src="@/assets/img/u3330.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <img src="@/assets/img/u3368.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  IDaaS添加并启用支付宝认证源</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;   企业管理员登录飞天云信IDaaS管理平台
                    <a href="https://open.weixin.qq.com/">飞天云信IDaaS管理平台</a> ;
                    <br/>
                    2.2 &nbsp;   登录成功后，在菜单栏【认证】-【认证源管理】-【添加认证源】找到支付宝；<br/>
                    <img src="@/assets/img/u3377.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.3 &nbsp;   点击支付宝，在配置表单中，填入所需信息；<br/>
                    <img src="@/assets/img/u3378.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    字段描述：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">显示名称</td>
                                <td>通常填写为支付宝扫码登录，也可自定义</td>
                            </tr>
                            <tr>
                                <td>支付宝应用ID</td>
                                <td>支付宝开放平台创建应用自动生成AppId</td>
                            </tr>
                            <tr>
                                <td>支付宝应用私钥</td>
                                <td>秘钥生成工具或openssl生成的应用私钥</td>
                            </tr>
                            <tr>
                                <td>支付宝公钥</td>
                                <td>支付宝开放平台设置接口加签后自动生成，在应用详情，接口加签方式中查看</td>
                            </tr>
                            <tr>
                                <td>回调地址</td>
                                <td>默认存在，需要将此链接配置到支付宝应用的授权回调地址中</td>
                            </tr>
                        </tbody>
                    </table>
                    2.4 &nbsp;   信息填写完成后，点击【提交】按钮保存。保存成功后，可在认证源列表看见新添加的支付宝认证源；<br/>
                    <img src="@/assets/img/u3380.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.5 &nbsp;   支付宝认证源添加后，需要在【应用】下选择用户门户应用，在【登陆配置】标签页下开启支付宝认证源，只有开启后，用户登录门户系统才可以通过支付宝认证源一键登录。<br/>
                    <img src="@/assets/img/u3381.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3.  支付宝扫码登陆</p>
                <div class="float"></div>
                <span class="text1">
                    登录用户门户，可以在登录页面看到支付宝登录方式，选择后弹出支付宝二维码，扫码后即可登录。
                    <br/>
                    注：第一次扫码登陆的时候，需要与用户手机号进行绑定，绑定之后再次用支付宝扫码登陆时可直接登录，无需再次绑定。
                    <img src="@/assets/img/u3382.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：微信认证源接入
                 </a>
                 <!-- <a href="##" style="float:right;" @click="next">
                     下一篇：配置QQ扫码登录
                    <a-icon type="arrow-right" />
                 </a> -->
                 <a href="##" style="float:right;" @click="next">
                     下一篇：短信验证码认证
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '配置过程' },
                { id: 'd2', title: '支付宝开放平台创建应用'},
                { id: 'd3', title: 'IDaaS添加并启用支付宝认证源' },
                { id: 'd4', title: '支付宝扫码登陆' },
            ],
            current:0,
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/WechatAccess"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    // path:"/configureQQLogin"
                    path:"/messageAuthentication"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
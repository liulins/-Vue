<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何访问企业主机</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍如何在飞天云信IDaaS添加公司应用系统，并开启单点登录，使用户可以通过用户门户单点登录应用系统。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    飞天云信IDaaS预集成国内外众多主流应用，通过SAML2、OIDC、OAuth2等国际标准化协议，满足企业BS应用、CS应用，以及自研应用等的单点登录，助力企业实现更高效、更安全的企业连接。提供标准的应用集成接口，用户通过简单的系统引导配置便可轻松实现标准业务应用的集成。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 添加飞天堡垒机</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp; 在【应用】-【企业应用列表】可以查看当前企业所有的应用系统；<br/>
                    1.3 &nbsp; 点击【添加应用】按钮，选择添加自建应用或者集成应用；<br/>
                    1.4 &nbsp; 选择【自建应用】，按要求填入信息后保存，即可在企业应用列表看到新添加的应用系统。<br/>
                    <img src="@/assets/img/u1366.png" class="img1" style="margin-top:10px;width:70%;height:70%;"/><br/>
                    字段说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">应用名称</td>
                                <td>你的应用名称</td>
                            </tr>
                            <tr>
                                <td>认证地址</td>
                                <td>选择一个二级域名，必须为合法的域名格式，例如 my-awesome-app</td>
                            </tr>
                            <tr>
                                <td>回调链接</td>
                                <td>此链接需要填写你的业务回调地址，用户在此应用登录之后，浏览器将会跳转到这个地址，你可以在这里换取用户信息。
                                    <br/>示例：https://myawesomeapp.com/login/callback</td>
                            </tr>
                        </tbody>
                    </table>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何绑定认证设备
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何设置密码策略
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '添加飞天堡垒机'},
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/bindAuthentication"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/settingPassword"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">管理员权限分配</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍介绍IT管理员如何在飞天云信IDaaS管理平台添加分级管理员，以及为管理员分配权限。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    管理员类型上分为三种：初始管理员、超级管理员和普通管理员。初始管理员指企业创建时生成的管理员，拥有全部权限，不可删除，初始管理员可创建超级管理员和普通管理员。超级管理员无任何权限限制，可以查看和编辑所有数据。普通管理员只能查看自己拥有的权限数据。管理员可以针对组织机构、菜单权限去创建分级管理员，并且可以基于自己拥有的权限，去分配或授予下级管理员同等的权限。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 添加管理员角色</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    1.2 &nbsp;   在【企业管理】-【管理员角色】模块，点击【添加】按钮去添加管理员角色；<br/>
                    1.3 &nbsp;   填写角色名称，选择菜单权限，添加描述信息后点击保存即可添加成功。<br/>
                    
                    <img src="@/assets/img/u5073.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  添加管理员</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;    在【企业管理】-【管理员角色】模块，点击【添加】按钮去添加管理员；<br/>
                    2.2 &nbsp;   在弹出的表单填写管理员信息，选择组织机构（选择机构后，此管理员只可查看对应机构的用户数据）、管理员角色（表示此管理员有权限查看角色对应的数据），填写完毕保存即可。<br/>                   
                    <img src="@/assets/img/u5074.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3.  管理员登录</p>
                <div class="float"></div>
                <span class="text1">
                    3.1 &nbsp;    用刚才添加的管理员账号密码登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>
                    ;<br/>
                    3.2 &nbsp;    登陆后可以查看并管理有权限的所有数据。<br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：自定义邮件网关配置
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：用户自助服务
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '添加管理员角色'},
                { id: 'd3', title: '添加管理员' },
                { id: 'd4', title: '管理员登录' },
            ],
            current:0,
            description1:"1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/userdefinedEmail"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/userService"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}

</style>
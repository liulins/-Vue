<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何设置登录方式</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍企业管理员登录管理平台，以及用户登录用户门户的登录方设置步骤。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    企业IT管理员表示企业管理者，管理员可在管理平台管理员工账号信息；用户指由IT管理员创建或导入的员工账号，是飞天云信IDaaS用户门户系统的最终使用者。
                    <br/>
                    IT管理员可为企业配置登录认证方式，企业管理员登录管理平台时按设置生效；IT管理员还可为用户门户系统配置登录认证方式，用户登录用户门户时按设置生效。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 管理员登陆设置</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp;  在【设置】-【企业配置】模块，选择【登陆配置】标签页，勾选「启用短信验证」后，企业管理员登陆管理平台时，输入手机号+密码后，还需短信验证码校验通过才可登陆成功。<br/>
                    <img src="@/assets/img/u2298.png" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                    1.3 &nbsp;  体验登录：企业管理员登录管理平台时验证短信验证码。若取消勾选「启用短信验证」后，则只需要输入手机号+密码即可登录。<br/>
                    <img src="@/assets/img/u2299.png" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 用户门户登陆设置</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;  选择【应用】-【企业应用列表】，这里展示当前企业所有的应用系统，其中「用户门户」应用是用户用于实现单点登录的应用系统；<br/>
                    2.2 &nbsp;   点击【用户门户】可以进入应用详情，选择【登陆配置】标签页，在这里可以对门户系统的登录及认证方式进行配置：<br/>
                    <ul>
                        <li style="margin-bottom:0;margin-top:5px;">
                            登录方式：可选择密码登录或者APP或小程序扫码登录。登录方式可多选，多选后用户可自由选择用哪种方式登录；默认登陆方式为单选，表示打开登陆页面时，默认展示哪种登陆方式。
                            <img src="@/assets/img/u2322.png" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                        </li>
                        <li style="margin-bottom:0;">
                            多因素认证：开启多因素认证后，用户在密码登陆/扫码登陆验证通过后，还需通过二次认证才可登录该应用，当同时开启多个多因素认证时，用户可自由选择采用哪种认证方式进行认证。
                            <img src="@/assets/img/u2323.png" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                        </li>
                        <li style="margin-bottom:0;">
                             认证源登陆：为应用开启某一认证源，用户在登录该应用时，允许通过该第三方认证源登录。
                            <img src="@/assets/img/u2325.jpg" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                        </li>
                    </ul> 
                    2.3 &nbsp;   体验登录：用户可以选择密码登录或扫码登陆方式，认证通过后需进行二次认证（按照设置的多因素认证方式），认证通过才可登录到门户系统。用户也可以直接采用设置的第三方认证源登录。<br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <!-- <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何切换登录风格
                 </a> -->
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何实现单点登录
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：飞书认证源接入
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '管理员登陆设置'},
                { id: 'd3', title: '用户门户登陆设置'},
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    // path:"/switchLogin"
                    path:"/achieveSingle"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/feishuAccess"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
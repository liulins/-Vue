<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何管理组织机构</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS新增、查看、编辑组织机构，以及成员添加/删除、变更部门等。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    组织机构管理功能将用户（员工）以组织机构划分，以方便统一管理以及集中授权。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 添加组织机构</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp; 在左侧菜单栏【用户】-【组织机构】右侧页面，点击机构后面的设置按钮，在展开的功能项中选择「添加下级组织机构」，在弹出的输入框填写机构信息，单击【保存】，即可为该机构添加下级机构。
                    <img src="@/assets/img/u1036.png" class="img1" style="margin-top:10px;margin-bottom:20px;"/><br/>
                    1.3 &nbsp; 或者可以点击【新建组织机构】按钮，在弹出的输入框填写机构信息，选择上级机构，单击【保存】，也可添加成功。
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 编辑组织机构</p>
                <div class="float"></div>
                <span class="text1">
                    对于已存在的组织机构，可以随时修改其基本信息。在【用户】-【组织机构】页面，点击机构后面的设置按钮，在展开的功能项中选择「编辑组织机构」，在弹出的输入框可更新机构信息，单击【保存】，即可编辑成功。
                </span>
                <img src="@/assets/img/u1037.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 移动组织机构</p>
                <span class="text1">
                    对于已存在的组织机构，可以任意移动使其变更上级机构。在【用户】-【组织机构】页面，点击组织机构后面的设置按钮，在展开的功能项中选择「移动组织机构」，在弹出的输入框填入要移动到的目标机构，单击【保存】即可。组织机构移动后，机构内用户跟随原机构移动。
                </span>
                <img src="@/assets/img/u1038.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d5" class="title1">
                <p class="title1_1">4. 删除组织机构</p>
                <span class="text1">
                    对于已存在的组织机构，可以在【用户】-【组织机构】页面，点击组织机构后面的设置按钮，在展开的功能项中选择「删除」按钮，即可删除该机构，同时该机构所有的子机构将全部删除。<br/>
                    注：组织机构删除时，应保证机构内没有成员才可删除。
                </span>
                <img src="@/assets/img/u1035.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d6" class="title1">
                <p class="title1_1">5. 添加/移除/删除成员</p>
                <span class="text1">
                    5.1 &nbsp;  点击某一组织机构，右侧列表展示机构内全部成员；<br/>
                    5.2 &nbsp; 创建用户：单击列表上方【创建用户】按钮，可选择企业内任意用户加入到该组织机构；<br/>
                    5.3 &nbsp; 删除用户：点击某一用户后面操作列的「删除用户」按钮，可将该成员删除。或勾选多个用户后，点击列表上方的【删除用户】按钮，将这些用户统一删除；<br/>
                    5.3 &nbsp; 迁移用户：点击某一用户后面操作列的「迁移用户」按钮可进行迁移。或勾选多个用户后，点击列表上方的【移除用户】按钮，可实现用户的统一迁移。<br/>
                </span>
                <img src="@/assets/img/u1039.png" class="img1" style="margin-top:10px;"/>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何管理用户组
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何为用户分配权限
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '添加组织机构'},
                { id: 'd3', title: '编辑组织机构' },
                { id: 'd4', title: '移动组织机构' },
                { id: 'd5', title: '删除组织机构' },
                { id: 'd6', title: '添加/移除/删除成员' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/manageUserGroup"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/assignPermission"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
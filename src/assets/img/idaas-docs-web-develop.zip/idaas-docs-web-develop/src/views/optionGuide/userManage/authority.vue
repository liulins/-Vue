<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何为用户分配权限</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS管理平台对用户进行细粒度授权。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    IDaaS权限系统可以对不同的组织机构、用户组、应用、人员等属性按需设置相应的访问权限，建立用户与权限间的动态关联，实现精细化授权，从而满足不同用户访问不同应用系统的需求。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 对用户授权</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp;添加应用授权：
                    <ul>
                        <li>
                             方式一：在【用户】模块，点击用户操作列的
                             <img src="@/assets/img/u585.png"/>
                             按钮进入详情页面，点击【授权管理】标签页，可以查看该用户有权访问的所有应用系统，支持手动添加和删除以实现实时的应用授权。
                            <img src="@/assets/img/u1150.png" class="img1" style="margin-top:10px;margin-bottom:20px;"/>
                        </li>
                        <li>
                             方式二：在【应用】模块的应用详情页面，选择【访问授权】标签页，在应用访问控制模块可以控制谁可以访问本应用，选择授权用户保存即可。
                            <img src="@/assets/img/u1151.png" class="img1" style="margin-top:10px;margin-bottom:20px;"/>
                        </li>
                    </ul>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 对用户组授权</p>
                <div class="float"></div>
                <span class="text1">
                    在【应用】模块的应用详情页面，选择【访问授权】标签页，在应用访问控制模块可以控制谁可以访问本应用，选择授权用户组保存即可。
                </span>
                <img src="@/assets/img/u1152.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 对组织机构授权</p>
                <span class="text1">
                    在【应用】模块的应用详情页面，选择【访问授权】标签页，在应用访问控制模块可以控制谁可以访问本应用，选择授权组织机构保存即可。<br/>
                    注：子节点继承表示已授权组织机构的下级机构是否可以继承权限，如果选择是，则授予下级机构的用户该应用的访问权限；如果选择否，则拒绝下级机构的用户访问该应用。
                </span>
                <img src="@/assets/img/u1153.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d5" class="title1">
                <p class="title1_1">4. 用户登录</p>
                <span class="text1">
                    4.1 &nbsp;  用户登录飞天云信IDaaS用户门户；<br/>
                    4.2 &nbsp; 登录成功后，在左侧菜单栏【应用中心】处，可以看到授权给该用户的所有应用系统，点击应用图标即可单点登录到应用系统（前提：保证该应用在IDaaS管理平台未开启多因素认证，否则需要通过多因素认证，认证通过后也可登录成功）。<br/>
                </span>
                <img src="@/assets/img/u1149.png" class="img1" style="margin-top:10px;"/>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何管理组织机构
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何绑定认证设备
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '对用户授权'},
                { id: 'd3', title: '对用户组授权' },
                { id: 'd4', title: '对组织机构授权' },
                { id: 'd5', title: '用户登录' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/manageOrganization"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/bindAuthentication"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
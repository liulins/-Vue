<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何管理应用子账号</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍如何添加应用子账号。添加应用子账号后，用户可以通过IDaaS单点登录到其他应用。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    「子账号」功能是将用户在IDaaS平台的账号与用户的应用账号进行绑定，通过账号映射，与应用的账号建立唯一标识，使用户可以一键登录所有应用，解决需要记忆多套账号的问题。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 添加应用子账号</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp;  在【应用】-【企业应用列表】可以查看当前企业所有的应用系统；<br/>
                    1.3 &nbsp;  进入应用详情后，选择【子账号】标签页，列表展示该应用下所有用户添加的子账号；<br/>
                    <img src="@/assets/img/u2009.png" class="img1" style="margin-bottom:10px;width:95%"/><br/>
                    1.4 &nbsp;  点击【添加子账号】按钮，可继续为该应用添加子账号。在弹出的添加窗口输入相关信息，点击保存即可。<br/>
                     <ul>
                        <li style="margin-bottom:0;margin-top:5px;">
                            主账号：飞天云信IDaaS用户唯一账号
                        </li>
                        <li style="margin-bottom:0;">
                            子账号： 应用账号名
                        </li>
                        <img src="@/assets/img/u2011.png" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                    </ul> 
                    1.5 &nbsp;  也可在【用户】-【用户列表】处进行绑定。在应用详情里选择【子账号】标签页，点击【添加子账号】进行绑定。<br/>
                     <ul>
                        <li style="margin-bottom:0;margin-top:5px;">
                            应用：选择准备通过该子账号登录的应用系统
                        </li>
                        <li style="margin-bottom:0;">
                            主账号：飞天云信IDaaS用户唯一账号
                        </li>
                        <li style="margin-bottom:0;">
                            子账号：应用账号名
                        </li>
                        <img src="@/assets/img/u2014.png" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                    </ul> 
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 登陆应用</p>
                <div class="float"></div>
                <span class="text1">
                    若用户在应用下已成功绑定子账号，则会直接使用子账号单点登陆到该应用系统。<br/>
                    <img src="@/assets/img/u2015.png" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：应用授权及登录配置
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何实现单点登录
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '添加应用子账号'},
                { id: 'd3', title: '登陆应用' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/applicationAuthorizate"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/achieveSingle"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">OTP动态口令认证</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS开启OTP动态口令认证、用户如何激活绑定OTP动态口令，以及如何使用OTP动态口令进行认证登录。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    在对外网开放的后台管理系统中，使用静态口令进行身份验证登录可能会存在被破解、被截获、被盗用等问题，OTP动态口令是一种重要的双因素认证技术，每隔30/60S变换一次，因此不可跟踪，防爆破，防轮询，有效避免弱密码以及静态密码的不安全因素。OTP动态令牌分为软件和硬件两种认证方式。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 开启OTP动态口令认证</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    1.2 &nbsp;   在【应用】-【企业应用列表】模块可以查看到企业集成的所有应用，包括用户门户应用系统，以及其他业务应用系统；<br/>
                    1.3 &nbsp;   选择某一应用，进入应用详情，选择【登陆配置】标签页，在多因素认证模块开启「OTP动态口令」。<br/>
                        <a-alert
                            class="explain"
                            message="说明"
                            description="1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；
                                        2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；
                                        3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
                            type="info"
                            show-icon
                            close-text="×"
                        />
                    <img src="@/assets/img/u3859.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  用户自助激活OTP手机令牌</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;    若用户未激活动态口令，可登录用户门户，进入【账号安全】；<br/>
                    2.2 &nbsp;   点击OTP手机令牌后面的【激活】按钮，按照指示进行激活。<br/>
                    <ul>
                        <li style="margin-bottom:0;">
                            步骤一：扫码下载飞天云信令APP，或扫描飞天云信令小程序码进入小程序；
                        </li>
                        <li style="margin-bottom:0;">
                            步骤二：打开飞天云信令APP或小程序，点击“扫一扫”按钮扫描激活二维码，待手机上显示动态口令后，将口令输入下方的输入框进行验证，点击完成按钮即可激活成功。
                        </li>
                    </ul>
                    <img src="@/assets/img/u3860.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3.  用户自助绑定OTP硬件令牌</p>
                <div class="float"></div>
                <span class="text1">
                    3.1 &nbsp;    登录用户门户，进入【账号安全】；<br/>
                    3.2 &nbsp;    点击OTP硬件令牌后面的【绑定】按钮，输入令牌序列号和动态口令进行绑定。<br/>
                    <img src="@/assets/img/u3865.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d5" class="title1">
                <p class="title1_1">4.  管理员为用户绑定硬件令牌</p>
                <div class="float"></div>
                <span class="text1">
                    4.1 &nbsp;    IT管理员在【用户】-【用户列表】模块可以查看到所有用户，选择某一用户，点击用户名进行用户详情页面；<br/>
                    4.2 &nbsp;    选择「认证设备」标签页，展示该用户已绑定的所有认证设备，点击【绑定硬件设备】按钮输入令牌系列号进行绑定；<br/>
                    <img src="@/assets/img/u3866.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d6" class="title1">
                <p class="title1_1">5.  OTP动态口令登录</p>
                <div class="float"></div>
                <span class="text1">
                    用户登录应用时，选择动态口令登录，输入手机令牌或硬件动态口令进行登录，或点击推送按钮，通过APP或小程序一键授权快速登陆，免除动态密码输入环节。
                    <br/>
                    <img src="@/assets/img/u1250.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：电子邮箱认证
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：FIDO UAF指纹/人脸认证
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '开启OTP动态口令认证'},
                { id: 'd3', title: '用户自助激活OTP手机令牌' },
                { id: 'd4', title: '用户自助绑定OTP硬件令牌' },
                { id: 'd5', title: '管理员为用户绑定硬件令牌' },
                { id: 'd6', title: 'OTP动态口令登录' },
            ],
            current:0,
            description1:"1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/emailAuthentication"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/UAFAuthentication"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
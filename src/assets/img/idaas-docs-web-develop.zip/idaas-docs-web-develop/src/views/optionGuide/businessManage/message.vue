<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">自定义短信网关配置</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍介绍IT管理员如何在飞天云信IDaaS管理平台配置自定义短信网关。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    飞天云信IDaaS默认使用平台提供的短信服务，同时也支持配置自定义短信网关，如华为云、阿里云、腾讯云、小水智能、助通科技等。使用自定义短信网关时， 需要企业提前在以上服务商中注册并购买消息&短信服务。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">应用场景</p>
                <div class="float"></div>
                <span class="text1">
                    通常在"短信验证码登录"、"注册"、"忘记密码"、"绑定手机号"等场景，会通过短信验证码对用户的身份进行确认。<br/>
                    <ul>
                        <li style="margin-bottom:0;">
                            短信验证码登录：管理员或用户开启短信认证登录时，可通过短信验证码的方式验证身份；
                        </li>
                        <li style="margin-bottom:0;">
                             注册企业：在IDaaS平台注册企业时，需要发送短信验证码绑定手机；
                        </li>
                        <li style="margin-bottom:0;">
                            用户绑定/修改手机号：用户绑定/修改手机号时，可通过短信验证码的方式验证身份；
                        </li>
                        <li style="margin-bottom:0;">
                            重置密码：用户重置密码时，可通过短信验证码的方式验证身份；
                        </li>
                        <li style="margin-bottom:0;">
                            重置令牌：用户重置令牌时，可通过短信验证码的方式验证身份；
                        </li>
                        <li style="margin-bottom:0;">
                            密码过期提醒：密码过期检查开启后，在密码过期前会通过短信提醒用户；
                        </li>
                        <li style="margin-bottom:0;">
                            临时认证：用户临时认证时，通过短信为用户发送临时口令。
                        </li>
                    </ul>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">1. 内置网关</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    1.2 &nbsp;   在【设置】-【企业配置】模块下，选择【短信网关配置】，可以查看您当前账户短信总量和剩余短信总量，以及查看发送场景和短信模板，<br/>
                    1.3 &nbsp;    在操作列的测试功能可以测试短信服务。<br/>
                        <a-alert
                            class="explain"
                            message="说明"
                            description="平台默认提供一定数量的免费短信，超额后平台提供的短信服务将无法使用，可续费享受更多优惠。"
                            type="info"
                            show-icon
                            close-text="×"
                        />
                    <img src="@/assets/img/u4847.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">2. 自定义网关</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;    短信服务配置：在自定义网关选项页，选择需要自定义的短信网关，不同的短信服务配置的参数不同，目前平台短信自定义网关服务商仅支持阿里云，后续会陆续支持其他短信服务的配置。<br/>
                    <img src="@/assets/img/u4786.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    阿里云配置参数说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>参数</th>
                                <th>参数说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">SMS服务商</td>
                                <td>阿里云短信网关（参考文档
                                    <a href="https://help.aliyun.com/product/44282.html?spm=a2c4g.11186623.6.540.1bc4c91dijWHVL">阿里云短信服务帮助文档</a>
                                    )
                                </td>
                            </tr>
                            <tr>
                                <td>Access Key ID</td>
                                <td>Access Key ID 用于标识用户（
                                    <a href="https://help.aliyun.com/document_detail/53045.html?spm=a2c4g.11186623.2.10.1bc4c91dijWHVL">Access Key说明</a>
                                    )
                                </td>
                            </tr>
                            <tr>
                                <td>Access Key Secret</td>
                                <td>Access Key Secret 是用来验证用户的密钥</td>
                            </tr>
                            <tr>
                                <td>签名名称</td>
                                <td>短信签名名称，需阿里云短信控制台审核通过后才能使用</td>
                            </tr>
                        </tbody>
                    </table>

                    2.2 &nbsp;    短信模板配置：为了确保业务的正常使用，管理员需要配置短信模板，后续短信服务将通过该配置的短信服务网关和短信模板进行发送。<br/>
                    2.3 &nbsp;    测试短信服务：在操作列-测试，可以测试短信服务。<br/>
                    <img src="@/assets/img/u4827.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：管理员操作日志
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：自定义邮件网关配置
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '应用场景'},
                { id: 'd3', title: '内置网关' },
                { id: 'd4', title: '自定义网关' },
            ],
            current:0,
            description1:"1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/adminLog"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/userdefinedEmail"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
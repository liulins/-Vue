<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">微信认证源接入</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍将微信认证源接入IDaaS中的过程，使用户可以通过微信扫码登录各应用系统。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1" >配置过程</p>
                <span class="text1">
                    <div>
                        <a-steps :current="current" >
                            <a-step title="步骤一" description="微信开放平台创建应用" />
                            <a-step title="步骤二" description="IDaaS平台添加并启用微信认证源" />
                            <a-step title="步骤三" description="微信扫码登陆" />
                        </a-steps>
                        <a-divider />
                    </div>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 微信开放平台创建应用</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 管理员需要在
                    <a href="https://open.weixin.qq.com/">微信开放平台</a> 注册开发者账号，注册后登录微信开放平台；
                    <br/>
                    1.2 &nbsp;   在【管理中心】-【网站应用】-【创建网站应用】去创建应用，按照要求填写信息，授权回调域填写飞天云信IDaaS地址，提交等待审核；<br/>
                    <img src="@/assets/img/u3141.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.3 &nbsp;   审核通过后获得AppID和AppSecret参数值。<br/>
                    <img src="@/assets/img/u3142.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  IDaaS添加并启用微信认证源</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;   企业管理员登录
                    <a href="https://open.weixin.qq.com/">飞天云信IDaaS管理平台</a> ;
                    <br/>
                    2.2 &nbsp;   登录成功后，在左侧菜单栏【认证】-【认证源管理】处，点击【添加认证源】按钮，在新页面找到微信认证源。点击后在弹出的表单中按要求填写信息；<br/>
                    <img src="@/assets/img/u3208.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <img src="@/assets/img/u3207.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                     字段说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">显示名称</td>
                                <td>通常填写为微信扫码登录，也可自定义</td>
                            </tr>
                            <tr>
                                <td>APPID</td>
                                <td>用户在微信开放平台申请的AppId</td>
                            </tr>
                            <tr>
                                <td>APPsecret</td>
                                <td>用户在微信开放平台申请的AppSecret</td>
                            </tr>
                        </tbody>
                    </table>
                    2.3 &nbsp;   信息填写完成后，点击【提交】按钮保存。保存成功后，可在认证源列表看见新添加的微信认证源；<br/>
                    <img src="@/assets/img/u3209.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.4 &nbsp;   微信认证源添加后，需要在【应用】-【企业应用列表】下选择用户门户应用，在【登陆配置】标签页下开启微信认证源，只有开启后，用户登录门户系统才可以通过微信认证源一键登录。<br/>
                    <img src="@/assets/img/u3210.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3.  微信扫码登陆</p>
                <div class="float"></div>
                <span class="text1">
                    登录用户门户，可以在登录页面看到微信登录方式，选择后弹出微信二维码，扫码后即可登录。
                    <br/>
                    注：第一次扫码登陆的时候，需要与用户进行绑定，绑定之后再次用微信扫码登陆时可直接登录，无需绑定。
                    <img src="@/assets/img/u3211.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：Windows AD认证源接入
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：支付宝认证源接入
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '配置过程' },
                { id: 'd2', title: '微信开放平台创建应用'},
                { id: 'd3', title: 'IDaaS添加并启用微信认证源' },
                { id: 'd4', title: '微信扫码登陆' },
            ],
            current:0,
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/WindowsAccess"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/alipayAccess"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何实现单点登录</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍管理员如何开启应用系统的单点登录，使用户可以通过用户门户单点登录应用系统。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    管理员在管理平台开启应用系统的单点登录，用户登陆用户门户系统后可单点登录这些应用，实现一次登录通达所有应用，无需再为记忆多个账户密码而感到烦恼，提升用户体验，助力企业实现更高效、更安全的企业连接。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 管理员开启应用权限</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp;  在【应用】-【企业应用列表】可以查看当前企业集成的所有应用系统；<br/>
                    1.3 &nbsp;  选择目标应用，查看该应用的授权用户，确保用户有该应用的访问权限。<br/>
                    <img src="@/assets/img/u2113.png" class="img1" style="margin-bottom:10px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 用户单点登录应用系统</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;  用户登录飞天云信IDaaS用户门户；<br/>
                    2.2 &nbsp;  登录成功后，在左侧菜单栏【应用中心】处，可以看到授权的所有应用系统，点击该应用图标即可单点登录到该应用系统（前提：保证该应用在IDaaS管理平台未开启多因素认证，否则需要通过多因素认证，认证通过后也可登录成功）。<br/>
                    <img src="@/assets/img/u1149.png" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何管理应用子账号
                 </a>
                 <!-- <a href="##" style="float:right;" @click="next">
                     下一篇：如何切换登录风格
                    <a-icon type="arrow-right" />
                 </a> -->
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何设置登录方式
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '管理员开启应用权限'},
                { id: 'd3', title: '用户单点登录应用系统' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/manageSubaccount"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    // path:"/switchLogin"
                    path:"/setLogin"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">钉钉认证源接入</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍将钉钉认证源接入IDaaS中的过程，使用户可以通过钉钉扫码登录各应用系统。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1" >配置过程</p>
                <span class="text1">
                    <div>
                        <a-steps :current="current" >
                            <a-step title="步骤一" description="登陆钉钉开发者后台创建应用" />
                            <a-step title="步骤二" description="IDaaS平台添加并启用钉钉认证源" />
                            <a-step title="步骤三" description="钉钉扫码登陆" />
                        </a-steps>
                        <a-divider />
                    </div>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 钉钉开发者后台创建应用</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 登录钉钉
                    <a href="https://open-dev.dingtalk.com">开发者后台</a>；
                    <br/>
                    1.2 &nbsp;   在顶部菜单【应用开发】-【企业内部开发】下创建应用，在弹出的表单中，应用类型选择H5微应用，再输入所需信息，并上传应用 Logo后，点击【确认创建】即可创建成功；<br/>
                    <img src="@/assets/img/u2618.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.3 &nbsp;   在【应用功能】-【登陆与分享】处填入回调域名（回调域名在IDaaS管理平台【认证源】的钉钉认证源处查看）；<br/>
                    <img src="@/assets/img/u2621.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.4 &nbsp;    在企业自建应用中找到刚添加的应用，点击进入应用详情，找到 App ID 和 App Secret，保存。<br/>
                    <img src="@/assets/img/u2620.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. IDaaS平台添加并启用钉钉认证源</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;   企业管理员登录飞天云信IDaaS管理平台;<br/>
                    2.2 &nbsp;   登录成功后，在【认证】-【认证源管理】-【添加认证源】找到钉钉登录， 点击后，在配置表单中，填入所需信息；<br/>
                    <img src="@/assets/img/u2622.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    字段描述：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">显示名称</td>
                                <td>通常填写为钉钉扫码登录，也可自定义</td>
                            </tr>
                            <tr>
                                <td>AppKey</td>
                                <td>钉钉应用的App ID</td>
                            </tr>
                            <tr>
                                <td>AppSecret</td>
                                <td>钉钉应用的App Secret</td>
                            </tr>
                        </tbody>
                    </table>
                    
                    2.3 &nbsp;   信息填写完成后，点击【创建】按钮保存。保存成功后，可在认证源列表看见新添加的钉钉认证源。<br/>
                    <img src="@/assets/img/u2623.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.4 &nbsp;    钉钉认证源添加后，需要在【应用】下选择用户门户应用，在【登陆配置】标签页下开启钉钉认证源，只有开启后，用户登录门户系统才可以通过钉钉认证源扫码登录。<br/>
                    <img src="@/assets/img/u2624.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 钉钉扫码登陆</p>
                <div class="float"></div>
                <span class="text1">
                    登录用户门户，可以在登录页面看到钉钉登录方式，选择后弹出钉钉二维码，扫码后即可登录。
                    <br/>
                    注：第一次扫码登陆的时候，需要与用户进行绑定，绑定之后再次用钉钉扫码登陆时可直接登录。
                    <img src="@/assets/img/u2625.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：飞书认证源接入
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：企业微信认证源接入
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '配置过程' },
                { id: 'd2', title: '钉钉开发者后台创建应用'},
                { id: 'd3', title: 'IDaaS平台添加并启用钉钉认证源' },
                { id: 'd4', title: '钉钉扫码登陆'},
            ],
            current:0,
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/feishuAccess"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/enterpriseAccess"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
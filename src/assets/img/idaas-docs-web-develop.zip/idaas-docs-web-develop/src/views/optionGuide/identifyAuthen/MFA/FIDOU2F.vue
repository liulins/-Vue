<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">FIDO U2F认证</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS为用户绑定FIDO U2F令牌，以及用户如何使用FIDO U2F令牌认证登录。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                   FIDO (Fast IDentity Online，快速在线身份识别）是一个开放协议,旨在打造一个安全、易用的通用认证接口，解决强认证设备之间的互操作性不足以及用户面临的密码问题（难以创建和记住多个密码）可以能够无缝地在windows、OSX和Linux上使用，一个U2F Key可支持多个服务，一个账号可绑定多个U2F Key，再也不用担心网络钓鱼或盗号的情况。FIDO推出两种用于在线强安全认证的协议：无密码UAF 指纹/人脸认证和双因素认证U2F。其中FIDO U2F认证是在默认登陆方式校验后增加一层硬件令牌验证身份，有效提高安全性。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 开启FIDO U2F认证</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    1.2 &nbsp;  在【应用】-【企业应用列表】模块可以查看到所有企业应用，包括用户门户应用系统，以及其他业务应用系统；<br/>
                    1.3 &nbsp;    选择某一应用，进入应用详情，选择【登陆配置】标签页，在多因素认证模块开启「FIDO U2F硬件」。<br/>
                        <a-alert
                            class="explain"
                            message="说明"
                            description="1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；
                                        2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；
                                        3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
                            type="info"
                            show-icon
                            close-text="×"
                        />
                    <img src="@/assets/img/u4087.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  为用户绑定FIDO U2F令牌</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;    IT管理员在【用户】-【用户列表】模块可以查看到所有用户，选择某一用户，点击操作列-编辑进行用户详情页面；<br/>
                    2.2 &nbsp;   选择「认证设备」标签页，展示该用户已绑定的所有认证设备，点击【绑定硬件设备】按钮完成激活；<br/>
                    <img src="@/assets/img/u3866.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.3 &nbsp;   U2F Key的使用：当用户登录受保护的网站时，网站将提示用户按下U2F Key 上面的按钮，用户按下按钮时，站点验证u2F Key 发送的秘钥，以决定用户是否可以登录。<br/>
                    
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3.  FIDO U2F令牌认证登录</p>
                <div class="float"></div>
                <span class="text1">
                    用户登录应用时，选择「FIDO U2F硬件」认证方式，点击登录按钮并连接 FIDO U2F Key，按下按键完成登录。<br/>
                    <img src="@/assets/img/u4063.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：FIDO UAF指纹/人脸认证
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：USBKey认证
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '开启FIDO U2F认证'},
                { id: 'd3', title: '为用户绑定FIDO U2F令牌' },
                { id: 'd4', title: 'FIDO U2F令牌认证登录' },
            ],
            current:0,
            description1:"1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/UAFAuthentication"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/USBAuthentication"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
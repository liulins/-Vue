<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">USBKey认证</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS为用户绑定USBKey硬件令牌，以及用户如何使用USBKey认证登录。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                   USBKey是采用高级智能卡技术的便携式双因素认证USB令牌，可以存储用户的私钥以及数字证书，利用USB Key内置的公钥算法实现对用户身份的认证，用户验证身份后才可登录，有效保护信息安全。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 开启USBKey认证</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    1.2 &nbsp;  在【应用】-【企业应用列表】模块可以查看到所有企业应用，包括用户门户应用系统，以及其他业务应用系统；<br/>
                    1.3 &nbsp;    选择某一应用，进入应用详情，选择【登陆配置】标签页，在多因素认证模块开启「USBKey硬件」。<br/>
                        <a-alert
                            class="explain"
                            message="说明"
                            description="1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；
                                        2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；
                                        3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
                            type="info"
                            show-icon
                            close-text="×"
                        />
                    <img src="@/assets/img/u4197.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  为用户绑定USBKey令牌</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;   IT管理员在【用户】-【用户列表】模块可以查看到所有用户，选择某一用户，点击操作列-编辑进行用户详情页面；<br/>
                    2.2 &nbsp;   选择「认证设备」标签页，展示该用户已绑定的所有认证设备，点击【绑定设备】按钮输入令牌系列号，连接USBKey硬件设备完成激活；<br/>
                    <img src="@/assets/img/u1247.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.3 &nbsp;   USBKey的使用：当用户登录受保护的网站时，网站将提示用户插入USBKey硬件设备以验证秘钥，通过后才可以登录成功。<br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3.  USBKey认证登录</p>
                <div class="float"></div>
                <span class="text1">
                    用户登录应用时，选择「USBKey硬件」认证方式，点击登录按钮并插入 USBKey硬件完成登录。<br/>
                    <img src="@/assets/img/u4173.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：FIDO U2F认证
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：LDAP作为身份源
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '开启USBKey认证'},
                { id: 'd3', title: '为用户绑定USBKey令牌' },
                { id: 'd4', title: 'USBKey认证登录' },
            ],
            current:0,
            description1:"1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/U2FAuthentication"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/LDAPIdentify"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何切换登陆风格</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍管理员如何设置用户的登录界面风格。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    用户门户登录界面风格可以在此处自定义，可统一品牌面貌，提升用户归属感与登录体验。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">界面配置</p>
                <div class="float"></div>
                <span class="text1">
                    1. &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    2. &nbsp;   选择左侧菜单栏【应用】-【企业应用列表】，右侧页面展示当前企业所有的应用系统，其中「用户门户」应用是用户用于实现单点登录的应用系统；<br/>
                    3. &nbsp;  点击【用户门户】应用头像可以进入应用详情，选择【界面配置】标签页，该模块可以对用户门户web端和移动端登录界面进行配置，选择IDaaS提供的内置模板，激活即可使用。<br/>
                    <ul>
                        <li style="margin-bottom:0;margin-top:5px;">
                            用户门户web端页面：
                            <img src="@/assets/img/u2113.png" class="img1" style="margin-bottom:10px;"/><br/>
                        </li>
                        <li style="margin-bottom:0;">
                            用户门户移动端页面：
                            <img src="@/assets/img/u2113.png" class="img1" style="margin-bottom:10px;"/><br/>
                        </li>
                    </ul> 
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何实现单点登录
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何设置登录方式
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '界面配置'},
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/achieveSingle"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/setLogin"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">用户自助服务</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍介绍用户如何在用户门户系统实现单点登录，以及对自己账号密码、认证方式等进行设置。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    飞天云信IDaaS用户门户系统是用于帮助用户实现单点登录的重要应用系统。应用中心用于展示企业所拥有的各类应用，通过IT管理员在管理平台的设置，使用户可以快速登陆业务系统，节省工作效率，再也无需记忆多套账号密码。用户还可以在用户门户系统对自己的账户进行自助设置，保护账号安全。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 用户登录用户门户</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 打开飞天云信IDaaS用户门户的登陆地址；
                    <!-- <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>； -->
                    <br/>
                    1.2 &nbsp;   用户需要输入他的用户名和密码,或者扫码登陆（根据管理平台的设置生效），或者通过第三方账号登录。如果用户不知道自己的用户名或忘记了密码，需要联系所在企业的 IT管理员，IT 管理员可以在管理平台为该用户修改密码。<br/>
                    <img src="@/assets/img/u5181.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  在应用中心管理应用</p>
                <div class="float"></div>
                <span class="text1">
                    应用中心会默认展示用户可访问的所有应用。用户可以随意卸载或添加自己的常用应用，也可手动或智能排序，以便降低不必要应用的干扰。用户点击某一应用，可以通过单点登陆/密码登陆进入应用系统。<br/>
                    <img src="@/assets/img/u5182.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3.  个人资料查看/编辑</p>
                <div class="float"></div>
                <span class="text1">
                    用户可以在个人资料页面来查看并编辑个人信息。<br/>
                    <img src="@/assets/img/u5183.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d5" class="title1">
                <p class="title1_1">4.  账号安全管理</p>
                <div class="float"></div>
                <span class="text1">
                    用户可以在账号安全页面去对自己的账号进行安全管理，管理内容包括：<br/>
                     <ul>
                        <li style="margin-bottom:0;">
                            登录密码：用户可在此处修改自己的登录密码；
                        </li>
                        <li style="margin-bottom:0;">
                             绑定/修改手机号：用户可在此处绑定/修改自己的手机号码；
                        </li>
                        <li style="margin-bottom:0;">
                            绑定/修改邮箱：用户可在此处绑定/修改自己的电子邮箱；
                        </li>
                        <li style="margin-bottom:0;">
                            OTP手机令牌： 用户可在此处按照指引激活OTP手机令牌；
                        </li>
                        <li style="margin-bottom:0;">
                            FIDO UAF令牌：用户可在此处按照指引激活FIDO UAF令牌；
                        </li>
                        <li style="margin-bottom:0;">
                            OTP硬件令牌：用户可在此处按照指引绑定OTP硬件令牌；
                        </li>
                        <li style="margin-bottom:0;">
                            FIDO U2F令牌：用户可在此处按照指引绑定FIDO U2F硬件令牌；
                        </li>
                        <li style="margin-bottom:0;">
                            多因素查看：用户可在此处查看支持的多因素认证方式。
                        </li>
                    </ul>
                    <img src="@/assets/img/u5184.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d6" class="title1">
                <p class="title1_1">5. 查看操作日志</p>
                <div class="float"></div>
                <span class="text1">
                    在用户门户系统，用户可自助查看行为日志。在左菜单栏【操作记录】可查看。<br/>
                    <img src="@/assets/img/u5185.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：管理员权限如何分配
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：阿里云用户SSO
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '用户登录用户门户'},
                { id: 'd3', title: '在应用中心管理应用' },
                { id: 'd4', title: '个人资料查看/编辑' },
                { id: 'd5', title: '账号安全管理' },
                { id: 'd6', title: '查看操作日志' },
            ],
            current:0,
            description1:"1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/adminPermission"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/aliUser"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}

</style>
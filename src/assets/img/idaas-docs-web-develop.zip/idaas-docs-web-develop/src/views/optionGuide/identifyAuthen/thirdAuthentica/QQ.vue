<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">QQ认证源接入</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍将QQ认证源接入IDaaS中的过程，使用户可以通过QQ扫码登录各应用系统。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1" >配置过程</p>
                <span class="text1">
                    <div>
                        <a-steps :current="current" >
                            <a-step title="步骤一" description="在 QQ互联管理中心创建网站应用" />
                            <a-step title="步骤二" description="IDaaS平台添加并启用QQ认证源" />
                            <a-step title="步骤三" description="QQ扫码登陆" />
                        </a-steps>
                        <a-divider />
                    </div>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. QQ互联管理中心创建应用</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 管理员登陆
                    <a href="https://connect.qq.com/">QQ互联管理中心</a>；
                    <br/>
                    1.2 &nbsp;   创建网站应用（开发者资料审核通过后才可创建应用））<br/>
                    <img src="@/assets/img/u3486.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.3 &nbsp;   审核通过后获得AppID和AppSecret参数值。<br/>
                    <img src="@/assets/img/u3488.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2.  IDaaS平台添加并启用QQ认证源</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;   企业管理员登录飞天云信IDaaS管理平台;<br/>
                    2.2 &nbsp;   登录成功后，在菜单栏【认证】-【认证源管理】-【添加】找到QQ；<br/>
                    <img src="@/assets/img/u3377.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.3 &nbsp;   点击QQ，在配置表单中，填入所需信息；<br/>
                    <img src="@/assets/img/u3378.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    字段描述：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">显示名称</td>
                                <td>通常填写为QQ扫码登录，也可自定义</td>
                            </tr>
                            <tr>
                                <td>APPID</td>
                                <td>在QQ互联管理中心申请的AppId</td>
                            </tr>
                            <tr>
                                <td>APPsecret</td>
                                <td>QQ互联管理中心申请的AppSecret</td>
                            </tr>
                        </tbody>
                    </table>
                    2.4 &nbsp;   信息填写完成后，点击【提交】按钮保存。保存成功后，可在认证源列表看见新添加的QQ认证源；<br/>
                    <img src="@/assets/img/u3380.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.5 &nbsp;   QQ认证源添加后，需要在【应用】下开启QQ认证源。<br/>
                    <img src="@/assets/img/u3381.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3.  QQ扫码登陆</p>
                <div class="float"></div>
                <span class="text1">
                    登录用户门户，我们可以在登录页面看到QQ登录方式，点击后可通过QQ扫码登陆。
                    <br/>
                    <img src="@/assets/img/u3516.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：支付宝认证源接入
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：短信验证码认证
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '配置过程' },
                { id: 'd2', title: 'QQ互联管理中心创建应用'},
                { id: 'd3', title: 'IDaaS平台添加并启用QQ认证源' },
                { id: 'd4', title: 'QQ扫码登陆' },
            ],
            current:0,
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/alipayAccess"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/messageAuthentication"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
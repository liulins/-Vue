<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何管理用户组</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍IT管理员如何在飞天云信IDaaS新增、编辑、删除用户组，并在用户组中新增或移除用户。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    用户组管理功能可以将部分用户（员工）分组，以便进行单独授权，独立管理。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 添加用户组</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp; 在左侧菜单栏【用户】-【用户组】右侧页面点击【创建分组】按钮，在弹出的输入框填写用户组信息，包括用户组名称和描述信息，单击【保存】，即可添加成功。
                </span>
                <img src="@/assets/img/u920.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 编辑用户组</p>
                <div class="float"></div>
                <span class="text1">
                    添加用户组后，可修改用户组名称及备注信息。<br/>
                    2.1 &nbsp;  在左侧菜单栏【用户】-【用户组】右侧页面，单击用户组操作列的
                    <img src="@/assets/img/u918.png"/>
                    按钮即可编辑；<br/>
                    2.2 &nbsp; 在弹出的输入框，修改用户组名称及备注信息后，单击【保存】即可。
                </span>
                <img src="@/assets/img/u921.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 删除用户组</p>
                <span class="text1">
                    如不再需要某些用户组，可点击操作列的删除按钮
                    <img src="@/assets/img/u919.png"/>
                    删除用户组。
                </span>
                <img src="@/assets/img/u922.png" class="img1" style="margin-top:10px;"/>
            </div>
            <div id="d5" class="title1">
                <p class="title1_1">4. 添加/移除用户</p>
                <span class="text1">
                    添加用户组后，可在用户组中添加/移除用户。<br/>
                    4.1 &nbsp;  在用户组页面，点击分组名称进入用户组详情页面，展示组内成员列表；<br/>
                    4.2 &nbsp; 单击【添加用户】按钮，可选择企业内任意用户加入到该用户组；<br/>
                    4.3 &nbsp; 点击组内成员的操作列-删除按钮，可将该成员移除用户组。<br/>
                </span>
                <img src="@/assets/img/u923.png" class="img1" style="margin-top:10px;"/>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何管理用户账号
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何管理组织机构
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '添加用户组'},
                { id: 'd3', title: '编辑用户组' },
                { id: 'd4', title: '删除用户组' },
                { id: 'd5', title: '添加/移除用户' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/manageAccount"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/manageOrganization"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
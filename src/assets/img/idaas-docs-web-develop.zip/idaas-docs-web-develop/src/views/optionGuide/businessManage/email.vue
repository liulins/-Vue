<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">自定义邮件网关配置</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍介绍IT管理员如何在飞天云信IDaaS管理平台配置自定义邮件网关。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    飞天云信IDaaS默认使用平台提供的邮件服务，同时也支持配置第三方邮件网关。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">应用场景</p>
                <div class="float"></div>
                <span class="text1">
                    通常在"邮件验证码登录"、"注册"、"忘记密码"、"绑定手机号"等场景，会通过短信验证码对用户的身份进行确认。<br/>
                    <ul>
                        <li style="margin-bottom:0;">
                             邮箱验证码登录：管理员或用户开启邮箱认证登录时，可通过邮箱验证码的方式验证身份；
                        </li>
                        <li style="margin-bottom:0;">
                             用户绑定/修改邮箱：用户绑定/修改邮箱时，可通过邮箱验证码的方式验证身份；
                        </li>
                        <li style="margin-bottom:0;">
                            通知用户：管理员进行用户重置密码操作时，可通过邮件的方式通知用户；
                        </li>
                        <li style="margin-bottom:0;">
                            激活令牌：用户需要临时认证时，通过邮件形式为用户发送激活二维码。
                        </li>
                    </ul>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">1. 基本配置</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    1.2 &nbsp;   在【设置】-【企业配置】模块下，选择【邮件网关配置】进入设置页面，若想要使用飞天默认邮件网关，则将上方的第三方邮件服务开关关闭即可；<br/>
                    1.3 &nbsp;    若要使用第三方邮件服务，则需要填写基本配置里面的配置信息，并开启上方的第三方邮件服务开关。<br/>
                    <img src="@/assets/img/u4967.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    配置参数说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>参数</th>
                                <th>参数说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">SMTP HOST</td>
                                <td>邮件网关服务主机地址</td>
                            </tr>
                            <tr>
                                <td>SMTP 端口</td>
                                <td>邮件网关服务对外端口，例如80</td>
                            </tr>
                            <tr>
                                <td>邮箱地址</td>
                                <td>发送邮件的邮箱地址</td>
                            </tr>
                            <tr>
                                <td>发送者名称</td>
                                <td>邮件发送名称</td>
                            </tr>
                            <tr>
                                <td>邮箱密码</td>
                                <td>发送邮件的邮箱账号密码</td>
                            </tr>
                            <tr>
                                <td>安全类型</td>
                                <td>单选 无、SSL、TLS</td>
                            </tr>
                        </tbody>
                    </table>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">2. 模板配置</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;    选择【模板配置】标签页设置邮件模板；<br/>
                    <img src="@/assets/img/u4970.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.2 &nbsp;    选择操作列-编辑图标，可针对不同发送场景自定义设置邮件内容，包括标题、落款、内容；<br/>
                    2.3 &nbsp;    选择操作列-预览图标，可实时预览邮件模板。<br/>
                    <img src="@/assets/img/u4971.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：自定义短信网关配置
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：管理员权限如何分配
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '应用场景'},
                { id: 'd3', title: '基本配置' },
                { id: 'd4', title: '模板配置' },
            ],
            current:0,
            description1:"1. 若为「用户门户」应用开启多因素认证方式，则用户在登陆用户门户系统时，除了密码/扫码登陆方式验证外，还需进行多因素认证才可登录；2. 若为「自建应用」和「集成应用」开启多因素认证，则用户在用户门户系统的应用面板上要登录这些应用时，需多因素认证通过才可访问；3. 若某一应用同时开启多种多因素认证方式，用户可自由选择一种认证方式登录。"
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/userdefinedSMS"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/adminPermission"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
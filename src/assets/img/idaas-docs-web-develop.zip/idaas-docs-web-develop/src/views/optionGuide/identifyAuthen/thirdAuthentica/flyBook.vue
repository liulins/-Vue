<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">飞书认证源接入</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍将飞书认证源接入IDaaS中的过程，使用户可以通过飞书扫码登录各应用系统。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1" >配置过程</p>
                <span class="text1">
                    <div>
                        <a-steps :current="current" >
                            <a-step title="步骤一" description="登陆飞书开发者后台创建应用" />
                            <a-step title="步骤二" description="IDaaS平台添加并启用企业微信认证源" />
                            <a-step title="步骤三" description="企业微信扫码登陆" />
                        </a-steps>
                        <a-divider />
                    </div>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 飞书开发者后台创建应用</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 在
                    <a href="https://open.feishu.cn/">飞天开放平台</a>
                    注册开发者账号，已有账号的可直接扫码登录
                    <a href="https://open.feishu.cn/app">开发者后台</a>；
                    <br/>
                    1.2 &nbsp;   登录成功后，点击「创建企业自建应用」，在弹出的表单输入应用名称和应用描述，并上传应用 Logo后，点击【确认创建】；<br/>
                    <img src="@/assets/img/u2469.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.3 &nbsp;   在企业自建应用中找到刚添加的应用，点击进入应用详情，找到 App ID 和 App Secret，保存。<br/>
                    <img src="@/assets/img/u2470.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.4 &nbsp;   在飞书应用详情的应用功能 - 网页页面，开启【启用网页】功能，网页设置可以随便填写，点击保存；<br/>
                    <img src="@/assets/img/u2473.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    1.5 &nbsp;   在飞书应用详情的【安全设置】处添加重定向URL，即回调地址，可以在IDaaS管理平台【认证源】的飞书认证源处查看。<br/>
                    <img src="@/assets/img/u2475.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <img src="@/assets/img/u2477.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. IDaaS平台添加并启用飞书认证源</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;   企业管理员登录飞天云信IDaaS管理平台;<br/>
                    2.2 &nbsp;   登录成功后，在【认证】-【认证源管理】-【添加认证源】找到飞书登录， 点击后，在配置表单中，填入所需信息；<br/>
                    <img src="@/assets/img/u2476.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    字段描述：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">显示名称</td>
                                <td>通常填写为飞书扫码登录，也可自定义</td>
                            </tr>
                            <tr>
                                <td>App ID</td>
                                <td>飞书应用的App ID</td>
                            </tr>
                            <tr>
                                <td>App Secret</td>
                                <td>飞书应用的App Secret</td>
                            </tr>
                            <tr>
                                <td>回调地址</td>
                                <td>默认，需要将此链接配置到飞书应用-安全设置的重定向URL中</td>
                            </tr>
                        </tbody>
                    </table>
                    
                    2.3 &nbsp;   信息填写完成后，点击【创建】按钮保存。保存成功后，可在认证源列表看见新添加的飞书认证源；<br/>
                    <img src="@/assets/img/u2478.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.4 &nbsp;   飞书认证源添加后，需要在【应用】下选择用户门户应用，在【登陆配置】标签页下开启飞书认证源，只有开启后，用户登录门户系统才可以通过飞书认证源一键登录。<br/>
                    <img src="@/assets/img/u2479.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 飞书登陆</p>
                <div class="float"></div>
                <span class="text1">
                    登录用户门户，可以在登录页面看到飞书登录方式，选择可通过飞书授权登陆。
                    <img src="@/assets/img/u2480.jpg" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：如何设置登录方式
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：钉钉认证源接入
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '配置过程' },
                { id: 'd2', title: '飞书开发者后台创建应用'},
                { id: 'd3', title: 'IDaaS平台添加并启用飞书认证源' },
                { id: 'd4', title: '飞书登陆'},
            ],
            current:0,
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/setLogin"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/dingdingAccess"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
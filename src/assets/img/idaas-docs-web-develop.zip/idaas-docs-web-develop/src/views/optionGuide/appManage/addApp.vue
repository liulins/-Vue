<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">如何添加应用</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍如何在飞天云信IDaaS添加公司应用系统，并开启单点登录，使用户可以通过用户门户单点登录应用系统。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">功能概述</p>
                <span class="text1">
                    飞天云信IDaaS预集成国内外众多主流应用，通过SAML2、OIDC、OAuth2等国际标准化协议，满足企业BS应用、CS应用，以及自研应用等的单点登录，助力企业实现更高效、更安全的企业连接。提供标准的应用集成接口，用户通过简单的系统引导配置便可轻松实现标准业务应用的集成。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1. 添加自建应用</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp; 以IT管理员账号登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>;<br/>
                    1.2 &nbsp; 在【应用】-【企业应用列表】右侧页面可以查看当前企业所有的应用系统；<br/>
                    1.3 &nbsp;  点击【添加应用】按钮，选择添加自建应用或者集成应用；<br/>
                    1.4 &nbsp; 选择【自建应用】，按要求填入信息后保存，即可在企业应用列表看到新添加的应用系统。<br/>
                    <img src="@/assets/img/u1366.png" class="img1" style="margin-bottom:10px;width:60%"/><br/>
                    字段说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">应用图标</td>
                                <td>你的应用图标</td>
                            </tr>
                            <tr>
                                <td>应用名称</td>
                                <td>你的应用名称</td>
                            </tr>
                            <tr>
                                <td>认证地址</td>
                                <td>选择一个二级域名，必须为合法的域名格式，例如 my-awesome-app</td>
                            </tr>
                            <tr>
                                <td>默认协议类型</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>登录回调 URL</td>
                                <td>此链接需要填写你的业务回调地址，用户在此应用登录之后，浏览器将会跳转到这个地址，你可以在这里换取用户信息。
                                    <br/>示例：https://myawesomeapp.com/login/callback</td>
                            </tr>
                            <tr>
                                <td>登出回调 URL</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>授权模式</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>返回类型</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>id_token 签名算法</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>启用 id_token 加密</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>授权码过期时间</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>id_token 过期时间</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>access_token 过期时间</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>refresh_token 过期时间</td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 添加集成应用</p>
                <div class="float"></div>
                <span class="text1">
                    点击【添加应用】按钮，选择【集成应用】进入应用市场，选择要集成的应用，按照应用集成教程填入信息后保存，即可在企业应用列表看到新添加的应用系统。<br/>
                     <img src="@/assets/img/u1798.png" class="img1" style="margin-bottom:10px;width:95%"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 访问授权</p>
                <div class="float"></div>
                <span class="text1">
                    在应用详情页面，选择【访问授权】标签页，可以授予用户该应用的访问权限。<br/>
                    <img src="@/assets/img/u1799.png" class="img1" style="margin-bottom:10px;width:95%"/><br/>
                </span>
            </div>
            <div id="d5" class="title1">
                <p class="title1_1">4. 体验登录</p>
                <div class="float"></div>
                <span class="text1">
                    4.1 &nbsp; 用户登录飞天云信IDaaS用户门户；<br/>
                    4.2 &nbsp; 登录成功后，在左侧菜单栏【应用中心】处，可以看到授权给该用户的所有应用系统，点击应用图标即可单点登录到应用系统（前提：保证该应用在IDaaS管理平台未开启多因素认证，否则需要通过多因素认证，认证通过后也可登录成功）。<br/>
                    <img src="@/assets/img/u1149.png" class="img1" style="margin-bottom:10px;margin-top:10px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：用户属性定义
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：应用授权及登录配置
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '功能概述' },
                { id: 'd2', title: '添加自建应用'},
                { id: 'd3', title: '添加集成应用' },
                { id: 'd4', title: '访问授权'},
                { id: 'd5', title: '体验登录' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/userAttribute"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/applicationAuthorizate"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
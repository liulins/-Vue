<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">有哪些认证协议</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">应用介绍</p>
                <span class="text1">
                      应用表示的是你现实中访问的业务应用。一个企业通常会有多个业务系统，例如人事、运维、销售、研发等不同员工角色都会同时对应多个业务系统，这些业务系统对应的就是IDaaS的应用。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">预集成应用</p>
                <div class="float"></div>
                <span class="text1"  style="margin-bottom:30px;">
                    飞天云信IDaaS预集成了国内外众多主流SaaS和本地部署应用，通过SAML2、OIDC、OAuth2等国际标准化协议，满足企业BS应用、CS应用，以及自研应用等的单点登录，企业管理员通过操作指引步骤去配置相应的连接参数，即可轻松完成应用的接入并使用，从而助力企业实现更高效、更安全的企业连接。
                </span>
                <img src="@/assets/img/u507.png" class="img1"/>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">自建应用</p>
                <div class="float"></div>
                <span class="text1"  style="margin-bottom:30px;">
                    飞天云信IDaaS为所有不在预集成列表中的商业应用或者企业自研应用提供SDK，企业管理员可以选择相应身份管理协议和认证管理协议，然后根据开放平台的协议文档进行集成开发适配。
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：什么是应用
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：如何管理用户账号
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '应用介绍' },
                { id: 'd2', title: '预集成应用' },
                { id: 'd3', title: '自建应用' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/application"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/manageAccount"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
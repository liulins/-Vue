<template>
    <div class=''>
        身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务
    </div>
</template>

<script>
export default {
    data() {
        return {

        };
    },
    created() {

    },
    methods: {

    },
}
</script>

<style lang='scss' scoped>

</style>
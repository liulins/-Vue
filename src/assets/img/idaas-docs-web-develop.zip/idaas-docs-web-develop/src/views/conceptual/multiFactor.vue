<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">什么是多因素认证</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">多因素认证介绍</p>
                <span class="text1" style="margin-bottom:30px;">
                     2017年新颁布的《信息安全技术 网络安全等级保护基本要求》（简称新等保2.0）中明确要求：应对同一用户采用两种或两种以上组合的鉴别技术实现身份鉴别。多因素认证（Multi Factor Authentication，简称 MFA）是在用户名称和密码之外再额外增加一层保护，以达到保护账号安全的作用，即用户在登陆时除了需要提供账号密码外，还需要进行第二次身份验证，以全面满足新等保2.0认证需求。目前使用多因素认证变成为企业保护数据安全，规避信息泄露的重要方式。
                </span>
                <span class="text1">
                    飞天云信IDaaS为Web应用、移动应用等多个渠道登录提供多种多因素认证方式及认证组合，允许按照不同业务场景灵活开启多因素认证，以适应不同安全级别的业务系统的认证，全面保护客户数据信息安全，为提升企业基础设施、网络及业务系统的账号安全提供保障。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">支持的认证方式</p>
                <div class="float"></div>
                <span class="text1">
                    飞天云信IDaaS为客户提供多种多因素认证方式及认证组合：
                    <ul>
                        <li style="margin-bottom:0;margin-top:10px;">
                             OTP手机令牌：通过APP/小程序端的动态口令认证登录，口令每隔30/60S变换一次，不可跟踪，防爆破，防轮询
                        </li>
                        <li style="margin-bottom:0;">
                            OTP硬件令牌：通过OTP硬件令牌认证登录，操作简单，认证方便
                        </li>
                        <li style="margin-bottom:0;">
                            短信验证码：整合三大运营商特有的数据网关认证能力，应用于用户注册、登录、身份校验等不同场景，有效避免静态密码登陆潜在的信息安全问题
                        </li>
                        <li style="margin-bottom:0;">
                             邮箱验证码：增加邮箱验证码校验，校验通过才可登陆，登陆操作更安全便捷
                        </li>
                        <li style="margin-bottom:0;">
                            FIDO UAF认证：支持人脸ID、指纹ID等生物特征认证，在静态账号密码校验后增加生物特征认证，再次提升账号安全
                        </li>
                        <li style="margin-bottom:0;">
                             FIDO U2F硬件令牌：通过FIDO U2F手持式硬件令牌进行身份认证，提升账号信息安全
                        </li>
                        <li style="margin-bottom:0;">
                            FIDO USBKey硬件令牌：通过数字证书认证提升账号信息安全
                        </li>
                    </ul> 
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：什么是单点登录
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：什么是应用
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '多因素认证介绍' },
                { id: 'd2', title: '支持的认证方式' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/single"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/application"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
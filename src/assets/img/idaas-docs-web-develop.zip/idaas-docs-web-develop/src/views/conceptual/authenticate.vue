<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">什么是认证源</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">认证源介绍</p>
                <span class="text1">
                    飞天云信IDaaS通过对身份源进行整合，可轻松借助第三方应用或外部认证源一键登陆。认证源包括微信、支付宝、微博等社交认证源，以及企业微信、飞书、钉钉等企业认证源，此外还支持AD、LDAP等本地认证源。飞天云信IDaaS已提前和这些认证源进行集成，管理员只需要配置相应的连接配置信息和映射关系，即可完成与各种认证源的对接，并使用这些认证源的原有账号登录平台。
                    <img src="@/assets/img/u326.png" class="img1"/>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">产品优势</p>
                <div class="float"></div>
                <span class="text1">
                    在EIAM场景下，企业经常会通过钉钉、企业微信、飞书等移动办公应用软件一键认证登陆；在CIAM场景下，客户大部分希望通过微信、支付宝、微博等社交认证源快速登录。飞天云信IDaaS针对EIAM+CIAM全场景用户的需求，预集成众多认证源来满足上述需求，可以极大地简化登陆流程，节省时间成本。
                    <ul>
                        <li style="margin-bottom:0;margin-top:10px;">
                             简化登录流程：用户使用第三方认证源登陆，基本只需要扫码一键登录，省去了填写复杂表单的注册流程，整个登录体验变得更加方便快捷
                        </li>
                        <li style="margin-bottom:0;">
                            减少密码依赖：使用第三方认证源认证登录可以使用户免于记忆额外的密码，从而减少用户对密码的依赖
                        </li>
                        <li style="margin-bottom:0;">
                            提升用户粘度：对于企业来说，第三方登录带来的无缝登录体验，可以激励用户持续使用他们的产品或服务，从而提升用户粘度
                        </li>
                        <li style="margin-bottom:0;">
                             保证信息安全：从第三方认证平台提供的认证反馈中对用户的身份进行更加准确的判断，从而对用户登录行为进行全方位安全防护
                        </li>
                        <li style="margin-bottom:0;">
                            降低时间成本：用户无需输入用户名和密码即可访问业务系统，因此可以大幅减少因密码问题所浪费的时间成本
                        </li>
                    </ul> 
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：什么是身份源
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：什么是单点登录
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            // anchorList: [
            //     { id: 'd1', title: '标题1' },
            //     { id: 'd2', title: '标题2', children: [
            //         { id: 'd3', title: '标题2-1', children: [
            //             { id: 'd4', title: '标题2-1-1' }
            //         ]},
            //     ]},
            //     { id: 'd4', title: '标题4' },
            //     { id: 'd5', title: '标题5' },
            //     { id: 'd6', title: '标题6' },
            // ]
            anchorList: [
                { id: 'd1', title: '认证源介绍' },
                { id: 'd2', title: '产品优势'},
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/identity"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/single"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
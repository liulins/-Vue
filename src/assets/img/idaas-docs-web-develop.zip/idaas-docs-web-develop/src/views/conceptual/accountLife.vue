<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <!-- <div ref="anchorRef" class="anchor-content">
            <div class="title">飞天云信IDaaS介绍</div>
            <div id="d1" class="text">d1    身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d2" class="text">d2     身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d3" class="text">d3   身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d4" class="text">d4   身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d5" class="text">d5   身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d6" class="text"> d6身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
        </div> -->
        <div ref="anchorRef" class="anchor-content">
            <div class="title">什么是账号生命周期管理</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">企业管理面临的问题</p>
                <span class="text1">
                    随着公司业务应用、员工数量大幅增加，人员流动和员工角色的转变都给企业管理造成了一定的负担，人员的入职、离职，以及岗位变动等时，管理者需为员工手动开启/关闭账号以及分配/收回权限，因此企业管理者的工作量急剧增加，并且手动管理，也会面临各种各样的问题，无法保证账号的及时开通与回收。例如：
                    <ul>
                        <li style="margin-bottom:0;margin-top:10px;">
                            员工入职，账户却未及时开通，影响员工正常工作；
                        </li>
                        <li style="margin-bottom:0;">
                            员工离职，账户却未及时回收，可能会导致公司数据泄露；
                        </li>
                        <li style="margin-bottom:0;">
                            员工调岗，账户权限未及时调整，信息不同步影响工作效率。
                        </li>
                    </ul>
                    传统的企业OA系统、HR系统、AD等可以实现账户管理，但是各系统身份信息独立，又面临着身份孤岛的新问题，信息同步困难，建设难度大，权限不集中等。所以，基于自动化授权的账户全生命周期管理需求日益急切。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">IDaaS账号全生命周期管理</p>
                <div class="float"></div>
                <span class="text1">
                    飞天云信IDaaS为解决企业账户管理难题，提供出一套完整的账户全生命周期管理解决方案，对用户身份统一维护，权限自动化分配，从而提升企业整体的业务安全系数和效率。
                    <ul>
                        <li style="margin-bottom:0;margin-top:10px;">
                            操作简单：管理员管理员工的入职离调过程十分简单，无需为每个员工单独进行设置，全部自动化管控；
                        </li>
                        <li style="margin-bottom:0;">
                            增效降本：员工账号从创建到注销，实现全流程的自动化管控，为企业管理者和员工的工作都带来了便利并有效节省成本；
                        </li>
                        <li style="margin-bottom:0;">
                            安全合规：避免因账户未及时回收而导致公司数据泄露的问题，保证访问全流程都有日志记录，有助于问题回溯和事故追责
                        </li>
                    </ul> 
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：什么是飞天云信IDaaS
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：什么是身份源
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            // anchorList: [
            //     { id: 'd1', title: '标题1' },
            //     { id: 'd2', title: '标题2', children: [
            //         { id: 'd3', title: '标题2-1', children: [
            //             { id: 'd4', title: '标题2-1-1' }
            //         ]},
            //     ]},
            //     { id: 'd4', title: '标题4' },
            //     { id: 'd5', title: '标题5' },
            //     { id: 'd6', title: '标题6' },
            // ]
            anchorList: [
                { id: 'd1', title: '企业管理面临的问题' },
                { id: 'd2', title: 'IDaaS账号全生命周期管理'},
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/userGroup"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/identity"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-anchor-link-title{
        color: #343434;
    }
    .ant-anchor-link-active > .ant-anchor-link-title{
        color: #1890ff;
    }
}
</style>
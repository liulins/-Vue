<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">什么是飞天云信IDaaS</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">飞天云信IDaaS介绍</p>
                <span class="text1">
                    身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">产品功能</p>
                <div class="float"></div>
                <ul>
                    <li>
                        <p>统一身份管理</p>
                        <p>飞天云信IDaaS针对内部员工、上下游合作伙伴、消费者等复杂多样的用户身份管理提供解决方案，通过飞天云信数字身份认证与安全管控平台（IAM）集中统一维护所有用户的身份信息和访问权限，轻松打通多种身份来源，构建统一身份标识，打通信息孤岛，实现员工全生命周期管理。</p>
                    </li>
                    <li>
                        <p> 统一应用管理</p>
                        <p>飞天云信IDaaS预集成国内外众多主流应用，通过SAML2.0、OIDC、OAuth2等国际标准化协议，满足企业BS应用、CS应用，以及自研应用等的单点登录，助力企业实现更高效、更安全的企业连接。并提供标准的应用集成接口，简单配置便可轻松集成。用户一次登陆后可访问授权范围的所有应用系统，无需再为记忆多个账户密码而感到烦恼。</p>
                    </li>
                    <li>
                        <p> 统一身份认证</p>
                        <p>通过短信、扫码、动态口令、推送、人脸、指纹、微信、钉钉、CA等多种认证技术，全面保护守护您的账号安全，让身份验证更简单。</p>
                    </li>
                    <li>
                        <p> 安全审计服务</p>
                        <p>提供大容量、高速度、智能化的日志分析与管控服务，保证全流程日志记录，实现跨域故障快速定位。</p>
                    </li>
                    <img src="@/assets/img/u132.png" class="img1"/>
                </ul>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">产品价值</p>
                <div class="float"></div>
                <ul>
                    <li>
                        <p>满足合规要求</p>
                        <p>符合商用密码安全性评估标准GB/T 39786—2021《信息安全技术信息系统密码应用基本要求》和等级保护2.0中关于身份鉴别相关要求。</p>
                    </li>
                    <li>
                        <p>消除信息孤岛</p>
                        <p>将多种身份源进行整合，构建统一身份标识，解决多账户、多密码痛点，提升用户体验。</p>
                    </li>
                    <li>
                        <p> 保护信息安全</p>
                        <p>提供安全可靠的身份管控和鉴权服务，运用多重防数据泄露措施，以及全方位的安全防护机制来降低数据泄露风险。</p>
                    </li>
                    <li>
                        <p> 提升管理效率</p>
                        <p>实现员工账号从创建到注销的全流程自动化管控，可以大幅提升企业的管理效率，降低管理成本。</p>
                    </li>
                </ul>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">解决方案</p>
                <div class="float"></div>
                <ul>
                    <li>
                        <p> EIAM解决方案</p>
                        <p>飞天云信IDaaS针对内部员工、上下游合作伙伴等企业内的身份管理（Employee IAM）提供解决方案，帮助整合部署在本地或云端的内部办公系统、业务系统，以及预集成行业内众多常用应用及SaaS应用，简单配置即能实现对接，即开即用，实现跨终端访问所有应用。企业间应用互联互通，保证工作高效便捷。</p>
                    </li>
                    <li>
                        <p>CIAM解决方案</p>
                        <p>飞天云信IDaaS针对外部消费者等终端用户的身份管理（Customer IAM）提供解决方案，实现跨平台、跨终端、高性能、高安全的用户身份管理，构建便捷高效的C端身份治理体系，提供安全的登陆和访问环境，实现全域用户安全自主可控。无论消费者是通过App、Web端、公众号、微信小程序等渠道进行访问，还是通过微信，钉钉等第三方认证方式进行登录，都可以快速识别用户身份，助力企业对用户行为进行偏好分析。</p>
                    </li>
                </ul>
            </div>
             <a-divider />
             <p class="end">
                 <!-- <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：
                 </a> -->
                 <a href="##" style="float:right;" @click="next">
                     下一篇：什么是账号生命周期管理
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            // anchorList: [
            //     { id: 'd1', title: '标题1' },
            //     { id: 'd2', title: '标题2', children: [
            //         { id: 'd3', title: '标题2-1', children: [
            //             { id: 'd4', title: '标题2-1-1' }
            //         ]},
            //     ]},
            //     { id: 'd4', title: '标题4' },
            //     { id: 'd5', title: '标题5' },
            //     { id: 'd6', title: '标题6' },
            // ]
            anchorList: [
                { id: 'd1', title: '飞天云信IDaaS介绍' },
                { id: 'd2', title: '产品功能'},
                { id: 'd3', title: '产品价值' },
                { id: 'd4', title: '解决方案' },
            ],
        };
    },
    mounted(){
        
    },
    created() {
    },
    methods: {
        next(){
            this.$router.push(
                {
                    path:"/userGroup2"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
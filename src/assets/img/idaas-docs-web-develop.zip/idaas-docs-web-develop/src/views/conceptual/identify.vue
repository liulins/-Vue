<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <!-- <div ref="anchorRef" class="anchor-content">
            <div class="title">飞天云信IDaaS介绍</div>
            <div id="d1" class="text">d1    身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d2" class="text">d2     身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d3" class="text">d3   身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d4" class="text">d4   身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d5" class="text">d5   身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
            <div id="d6" class="text"> d6身份即服务IDaaS（Identity as a Service，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。e，简称IDaaS）是云计算时代的IAM（身份识别和访问管理）服务，也可理解为SaaS化的IAM，是由第三方服务商构建、运行在云上的身份验证。飞天云信IDaaS是飞天诚信为客户提供的一套集统一身份管理、统一身份认证、统一授权管理、统一应用管理、统一审计管理五项能力于一体的身份管理与认证服务，兼容EIAM+CIAM全栈使用场景及解决方案，助力企业快速构建全场景、标准化的IDaaS云身份管理服务。</div>
        </div> -->
        <div ref="anchorRef" class="anchor-content">
            <div class="title">什么是身份源</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">身份源介绍</p>
                <span class="text1">
                    飞天云信IDaaS提供身份数据同步的能力，数据传递模式为：上游-中游-下游。其中“上游”代表着各种核心身份源数据，例如微信、支付宝、钉钉、企业微信、飞书、HR系统、AD、LDAP等；"中游"即是飞天云信IDaaS系统；"下游"则代表各类应用系统。飞天云信IDaaS已提前和这些身份源进行集成，以便客户通过简单的配置即可完成连接，通过映射、关联等与企业主账号源打通，人员、机构信息实时下拉，形成OneID统一的用户身份，保证人员的入离调转全生命周期管理安全。
                </span>
                <img src="@/assets/img/u133.png" class="img1"/>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：什么是账号生命周期管理
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：什么是认证源
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            // anchorList: [
            //     { id: 'd1', title: '标题1' },
            //     { id: 'd2', title: '标题2', children: [
            //         { id: 'd3', title: '标题2-1', children: [
            //             { id: 'd4', title: '标题2-1-1' }
            //         ]},
            //     ]},
            //     { id: 'd4', title: '标题4' },
            //     { id: 'd5', title: '标题5' },
            //     { id: 'd6', title: '标题6' },
            // ]
            anchorList: [
                { id: 'd1', title: '身份源介绍' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/userGroup2"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/authentication"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
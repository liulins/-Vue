<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">什么是单点登录</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1">单点登录介绍</p>
                <span class="text1" style="margin-bottom:30px;">
                    单点登录（Single Sign On，简称SSO）是指用户只需输入一次用户密码，完成一次认证登录后，不同应用之间的登录状态就已经互相打通，用户可直接访问所有相互信任的业务系统。具体实现是用户完成一次认证后，该用户账号在IDaaS就是已登录的状态，单点登录其他业务系统时，会向IDaaS询问该用户是否为登录状态，得到确认后即可完成多个应用系统间的单点登录行为。此服务可以涵盖用户在公有云和私有云中的双重需求，助力企业解决不同业务间的身份认证难题。
                </span>
                <span class="text1">
                    目前飞天云信IDaaS已经预集成了国内外众多主流应用，通过SAML2、OIDC、OAuth2等国际标准化协议，满足企业BS应用、CS应用，以及自研应用等的单点登录，助企业实现更高效、更安全的企业连接，并且提供标准的应用集成接口，用户通过简单的系统引导配置便可轻松实现标准业务应用的集成。
                </span>
                <img src="@/assets/img/u380.svg" class="img1" style="margin-top:10px;"/>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：什么是认证源
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：什么是多因素认证
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '单点登录介绍' },
            ]
        };
    },
    created() {
    },
    methods: {
        prev(){
            this.$router.push(
                {
                    path:"/authentication"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/multiFactor"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
</style>
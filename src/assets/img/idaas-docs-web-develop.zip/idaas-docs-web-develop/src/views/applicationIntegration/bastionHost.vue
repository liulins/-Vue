<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">飞天堡垒机</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍将纷享销客集成到IDaaS中的过程，使用户可以在用户门户单点登录纷享销客应用系统。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1" >配置过程</p>
                <span class="text1">
                    <div>
                        <a-steps :current="current" >
                            <a-step title="步骤一" description="申请纷享销客域名" />
                            <a-step title="步骤二" description="IDaaS平台添加纷享销客" />
                            <a-step title="步骤三" description="纷享销客系统配置" />
                            <a-step title="步骤四" description="体验单点登录" />
                        </a-steps>
                    </div>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1.  申请纷享销客域名</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp;  管理员账号登录
                    <a href="https://www.fxiaoke.com/pc-login/build/login.html">纷享销客</a>；
                    <br/>
                    1.2 &nbsp;   登录成功后，点击右上角「设置」按钮进入企业管理后台，在【企业设置】-【域名管理】处输入一个域名并申请，等待审核通过。<br/>
                    <img src="@/assets/img/u6007.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. IDaaS平台添加纷享销客</p>
                <div class="float"></div>
                <span class="text1">
                    2.1 &nbsp;   企业管理员登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>
                    ；
                    <br/>
                    2.2 &nbsp;   登录成功后，在菜单栏【应用】-【企业应用列表】处，点击【添加应用】按钮，选择【集成应用】后进入应用市场，选择【纷享销客】，填写应用名称、认证地址、纷享销客域名、单点登录 URL后保存。<br/>
                    <img src="@/assets/img/u6006.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    字段说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">集成应用名称</td>
                                <td>通常填写为纷享销客，也可自定义。此名称会展示在你的应用列表首页</td>
                            </tr>
                            <tr>
                                <td>认证地址</td>
                                <td>可随意填写，用户可直接复制该链接登陆到腾讯云控制台</td>
                            </tr>
                            <tr>
                                <td>纷享销客域名</td>
                                <td>在分享销客申请的域名</td>
                            </tr>
                            <tr>
                                <td>单点登录 URL</td>
                                <td>在分享销客企业设置 -> 企业安全设置 -> 单点登录处查看</td>
                            </tr>
                        </tbody>
                    </table>
                    纷享销客域名获取：使用管理员账号登录纷享销客，点击右上角「设置」按钮进入企业管理后台，在【企业设置】-【域名管理】处查看；单点登录 URL获取：在【企业设置】-【企业安全设置】-【 单点登录】处查看。
                    <img src="@/assets/img/u6008.png" class="img1" style="margin-bottom:10px;margin-top:15px;width:70%;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 纷享销客系统配置</p>
                <div class="float"></div>
                <span class="text1">
                    <a-alert
                        class="explain"
                        style="margin-top:0;"
                        message="前提条件："
                        description="1.管理员拥有纷享销客账号
                                    2.管理员拥有IDaaS企业中心访问权限"
                        type="warning"
                        show-icon
                        close-text="×"
                    />
                    3.1 &nbsp;    以管理员身份登录
                    <a href="https://www.fxiaoke.com/pc-login/build/login.html">纷享销客</a>;
                    <br/>
                    3.2 &nbsp;   在【企业设置】-【企业安全设置】-【 单点登录】处填入下列信息；<br/>
                    <img src="@/assets/img/u6016.png" class="img1" style="margin-bottom:10px;margin-top:15px;width:80%;"/><br/>
                    信息查看：登陆IDaaS管理平台，在【应用】-【企业应用列表】找到刚才添加的纷享销客应用，点击应用头像进去应用详情，在通用配置标签页查看。<br/>
                    <img src="@/assets/img/u6017.png" class="img1" style="margin-bottom:10px;"/><br/>
                </span>
            </div>
            <div id="d5" class="title1">
                <p class="title1_1">4. 体验单点登录</p>
                <div class="float"></div>
                <span class="text1">
                    4.1 &nbsp;   登录用户门户系统；
                    <br/>
                    4.2 &nbsp;   登录成功后，在菜单栏【应用中心】处，可以看到刚才添加的纷享销客应用系统，点击应用图标可以单点登录到纷享销客应用系统（前提：保证该应用在IDaaS管理平台开启了单点登录；若未开启单点登录，则需要通过多因素认证，认证通过后也可登录进去）。<br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：纷享销客
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：移动端APP应用
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '配置过程' },
                { id: 'd2', title: '申请纷享销客域名'},
                { id: 'd3', title: 'IDaaS平台添加纷享销客' },
                { id: 'd4', title: '纷享销客系统配置'},
                { id: 'd5', title: '体验单点登录'},
            ],
            current:0,
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/enjoyPin"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/mobileApp"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
}
</style>
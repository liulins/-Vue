<template>
    <div class='views-content'>
        <v-anchor :anchorList="anchorList"></v-anchor>
        <div ref="anchorRef" class="anchor-content">
            <div class="title">阿里云角色SSO</div>
            <p class="date">
                <a-icon type="eye" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>200</span>
                <a-icon type="history" :style="{color:'#C7C7C7',fontSize:'13px'}"/>
                <span>2017-1-12 12:12</span>
            </p>
            <div class="line"></div>
            <p class="introduce">
                本页面主要介绍将阿里云角色SSO集成到IDaaS中的过程，使用户可以在用户门户单点登录阿里云控制台。
            </p>
            <div class="float"></div>
            <div id="d1" class="title1">
                <p class="title1_1" >配置过程</p>
                <span class="text1">
                    <div>
                        <a-steps :current="current" >
                            <a-step title="步骤一" description="IDaaS平台添加阿里云角色SSO" />
                            <a-step title="步骤二" description="阿里云系统配置" />
                            <a-step title="步骤三" description="体验单点登录" />
                        </a-steps>
                    </div>
                </span>
            </div>
            <div id="d2" class="title1">
                <p class="title1_1">1.  IDaaS平台添加阿里云角色SSO</p>
                <div class="float"></div>
                <span class="text1">
                    1.1 &nbsp;  企业管理员登录
                    <a href="https://idaasadmin.cloudentify.com/">飞天云信IDaaS管理平台</a>；
                    <br/>
                    1.2 &nbsp;   登录成功后，在菜单栏【应用】-【企业应用列表】处，点击【添加应用】按钮，选择【集成应用】后进入应用市场，选择【阿里云角色SSO】，填写表单信息后保存。<br/>
                    <img src="@/assets/img/u5495.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    字段说明：<br/>
                    <table class="fontField">
                        <thead>
                            <tr>
                                <th>字段</th>
                                <th>字段说明</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="width: 300px;">集成应用名称</td>
                                <td>通常填写为阿里云角色SSO，也可自定义。此名称会展示在你的应用列表首页</td>
                            </tr>
                            <tr>
                                <td>认证地址</td>
                                <td>可随意填写，配置完成后用户可复制该链接直接登陆到阿里云控制台</td>
                            </tr>
                            <tr>
                                <td>云账号</td>
                                <td>账号ID，可在 阿里云查看（鼠标放在右上角头像上，可以看到账号 ID）</td>
                            </tr>
                            <tr>
                                <td>角色名</td>
                                <td>可随意填写，但需与阿里云控制台处的角色名称保持一致 控制台 查看</td>
                            </tr>
                            <tr>
                                <td>提供商名</td>
                                <td>可随意填写，但需与阿里云控制台处的提供商名称保持一致</td>
                            </tr>
                            <tr>
                                <td>角色会话名</td>
                                <td>可随意填写，角色SSO登陆时的角色会话名称</td>
                            </tr>
                            <tr>
                                <td>会话时间</td>
                                <td>设置角色最大会话时间，取值范围3600~43200秒</td>
                            </tr>
                            <tr>
                                <td>自定义扩展属性</td>
                                <td>可增加扩展属性</td>
                            </tr>
                        </tbody>
                    </table>
                    云账号获取：鼠标放在右上角头像上，可以看到账号 ID<br/>
                    <img src="@/assets/img/u5345.png" class="img1" style="margin-bottom:10px;margin-top:15px;width:30%;"/><br/>
                </span>
            </div>
            <div id="d3" class="title1">
                <p class="title1_1">2. 阿里云系统配置</p>
                <div class="float"></div>
                <span class="text1">
                    <a-alert
                        class="explain"
                        style="margin-top:0;"
                        message="前提条件："
                        description="1.管理员拥有阿里云账号
                                    2.管理员拥有IDaaS企业访问权限"
                        type="warning"
                        show-icon
                        close-text="×"
                    />

                    2.1 &nbsp;   以管理员身份登录
                    <a href="https://ram.console.aliyun.com/">阿里云控制台</a>
                    ，进入访问控制；
                    <br/>
                    2.2 &nbsp;   创建身份提供商：左侧边栏【SSO管理】-【角色SSO】-【SAML】选项卡下，点击【创建身份提供商】按钮，填写表单信息及上传元文件，上传后保存即可；<br/>
                    <img src="@/assets/img/u5496.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <img src="@/assets/img/u5497.png" class="img1" style="margin-bottom:10px;margin-top:15px;width:80%"/><br/>
                    身份提供商名称和元数据获取：“身份提供商名称”与IDaaS管理平台填写的“提供商名”保持一致；元数据文件下载路径：在IDaaS管理平台的【应用】下找到新添加的阿里云角色SSO应用，点击应用头像进入应用详情，在通用配置处下载。<br/>
                    <img src="@/assets/img/u5498.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    2.3 &nbsp;    新建RAM角色：点击左侧菜单【身份管理】-【角色】，在右侧页面点击【创建角色】按钮，选择可信实体类型为身份提供商，角色名称填入IDaaS管理平台-阿里云角色SSO的“角色名”即可。<br/>
                    <img src="@/assets/img/u5500.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                    <img src="@/assets/img/u5501.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <div id="d4" class="title1">
                <p class="title1_1">3. 体验单点登录</p>
                <div class="float"></div>
                <span class="text1">
                    3.1 &nbsp;   登录用户门户系统；
                    <br/>
                    3.2 &nbsp;   登录成功后，在菜单栏【应用中心】处，可以看到刚才添加的阿里云角色SSO应用系统，点击应用图标可以单点登录到阿里云控制台（前提：保证该应用在IDaaS管理平台开启了单点登录；若未开启单点登录，则需要通过多因素认证，认证通过后也可登录进去）。<br/>
                    <img src="@/assets/img/u5502.png" class="img1" style="margin-bottom:10px;margin-top:15px;"/><br/>
                </span>
            </div>
            <a-divider />
             <p class="end">
                 <a href="##" style="float:left;" @click="prev">
                     <a-icon type="arrow-left"/>
                     上一篇：阿里云用户SSO
                 </a>
                 <a href="##" style="float:right;" @click="next">
                     下一篇：腾讯云用户SSO
                    <a-icon type="arrow-right" />
                 </a>
             </p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            anchorList: [
                { id: 'd1', title: '配置过程' },
                { id: 'd2', title: 'IDaaS平台添加阿里云角色SSO'},
                { id: 'd3', title: '阿里云系统配置' },
                { id: 'd4', title: '体验单点登录'},
            ],
            current:0,
        };
    },
    created() {
    },
    methods: {
        onChange(current) {
            console.log('onChange:', current);
            this.current = current;
        },
        prev(){
            this.$router.push(
                {
                    path:"/aliUser"
                }
            )
            
        },
        next(){
            this.$router.push(
                {
                    path:"/tencentUser"
                }
            )
        }
    },
}
</script>

<style lang='scss' scoped>
.text {
    height: 500px;
    margin: 50px 0;
}
::v-deep{
    .ant-steps-horizontal:not(.ant-steps-label-vertical) .ant-steps-item-description {
        max-width: 185px;
    }
    .ant-steps-item-wait .ant-steps-item-icon{
        background-color: #1890ff;
        border-color: #fff;
    }
    .ant-steps-item-wait .ant-steps-item-icon > .ant-steps-icon{
        color: #fff;
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-title{
        color: rgba(0, 0, 0, 0.65);
    }
    .ant-steps-item-wait > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-steps-item-process > .ant-steps-item-container > .ant-steps-item-content > .ant-steps-item-description{
        color: #666;
    }
    .ant-anchor-link-title{
        color: #343434;
    }
    .ant-anchor-link-active > .ant-anchor-link-title{
        color: #1890ff;
    }
}
</style>
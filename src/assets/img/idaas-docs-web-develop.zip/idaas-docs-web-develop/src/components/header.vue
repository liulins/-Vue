<template>
	<div class="header-box">
		<div class="logo-box">
			<img src="@/assets/img/logo.png" alt="">
		</div>
		<!-- <a-icon class="collapsed-box" @click="collapsedFun" :type="this.$store.state.collapsed ? 'menu-unfold' : 'menu-fold'"/> -->
		<a-menu class="header-menu" v-model="current" mode="horizontal">
			<a-menu-item key="1">基本概念 </a-menu-item>
			<a-menu-item key="2">操作指引 </a-menu-item>
			<a-menu-item key="3">应用集成 </a-menu-item>
			<a-menu-item key="4">快速接入 </a-menu-item>
		</a-menu>
	</div>
</template>

<script>
import { mapMutations } from 'vuex'

export default {
	data() {
		return {
			current: ['1'],
		};
	},
	methods: {
    	...mapMutations(['collapsedFun'])
	}
};
</script>

<style lang="scss" scoped>
.header-box ::v-deep {
	height: 80px;
	background: #fff;
	display: flex;
    box-shadow: 0px 0px 5px 2px rgba(0, 0, 0, 0.1);
	z-index: 1;
	position: relative;
	.logo-box {
		padding: 10px 20px;
		width: 300px;
		text-align: center;
		margin-right: 15px;
		// box-shadow: 0px 0px 12px 1px rgba(0, 0, 0, 0.08);
		img {
			height: 100%;
		}
	}
	.ant-menu-horizontal {
		border: 0;
		line-height: 78px;
		font-size: 16px;
		.ant-menu-item {
			margin: 0 10px;
		}
	}
	.collapsed-box {
		display: flex;
    	align-items: center;
		font-size: 20px;
	}
	.ant-menu-item {
		border: 0 !important;
	}
}
</style>

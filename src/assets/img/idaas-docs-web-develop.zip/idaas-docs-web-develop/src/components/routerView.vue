<template>
    <!-- <transition name="slide-fade"> -->
        <router-view></router-view>
    <!-- </transition> -->
</template>

<script>
export default {
    data() {
        return {

        };
    },
    created() {

    },
    methods: {
      
    },
    computed: {
      
    },
}
</script>

<style lang='scss' scoped>
// .slide-fade-enter-active {
//     position: absolute !important;
//     width: calc(100%) !important;
//   transition: all .35s linear;
// }
// .slide-fade-leave-active {
//     position: absolute !important;
//     width: calc(100%) !important;
//   transition: all .85s linear;
// }
// .slide-fade-enter, .slide-fade-leave-to {
//   transform: translateX(calc(100%));
//   opacity: 0;
// }
</style>
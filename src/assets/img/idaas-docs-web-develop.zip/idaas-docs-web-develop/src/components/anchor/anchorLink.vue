<template functional>
    <a-anchor-link :href="'#'+props.data.id" :title="props.data.title">
        <span v-for="item in props.data.children">
            <a-anchor-link v-if="!item.children" :href="'#'+item.id" :title="item.title"></a-anchor-link>
            <AnchorLink v-else :data="item"></AnchorLink>
        </span>
    </a-anchor-link>
</template>

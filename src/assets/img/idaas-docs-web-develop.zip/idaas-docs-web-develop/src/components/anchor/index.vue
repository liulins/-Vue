<template>
    <a-anchor class="anchor-box" :offsetTop="offsetTop" :getContainer="()=>this.$parent.$refs.anchorRef" @change="anchorChange">
        <template v-for="item in anchorList">
            <!-- 一级 -->
            <a-anchor-link v-if="!item.children" :href="'#'+item.id" :title="item.title"></a-anchor-link>
            <AnchorLink v-else :data="item"></AnchorLink>
        </template>
    </a-anchor>
</template>

<script>
import AnchorLink from './anchorLink';
export default {
    components: {
        AnchorLink
    },
    data() {
        return {
        };
    },
    props: {
        anchorList: Array, // 描点数据
        offsetTop: { // 距离顶部偏移量
            type: Number,
            default: 20
        }
    },
    methods: {
        anchorChange(e) {
            this.$emit("anchorChange", e)
        }
    },
}
</script>

<style lang='scss' scoped>
.anchor-box {
    position: fixed;
    right: 30px;
    top: 100px;
    width: 200px;
}
</style>
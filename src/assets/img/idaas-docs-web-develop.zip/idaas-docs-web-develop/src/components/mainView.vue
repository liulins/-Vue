<template>
    <div class='main-view'>
        <VHeader></VHeader>
        <div class="menu-content">
            <VMenu></VMenu>
            <div class="content">
                <router-view class="content-box"></router-view>
            </div>
        </div>
    </div>
</template>

<script>
import VMenu from './menu/index'
import VHeader from './header'

export default {
    components: { VMenu, VHeader },
    data() {
        return {

        };
    },
    created() {

    },
    methods: {

    },
}
</script>

<style lang='scss' scoped>
.main-view {
    height: 100%;
    display: flex;
    flex-direction: column;
    .menu-content {
        flex: 1;
        display: flex;
        overflow: auto;
        .content {
            flex: 1;
            // margin: 10px;
            border-radius: 3px;
            overflow: auto;
            background: #fff;
            .content-box {
                // min-width: 1500px;
                height: 100%;
            }
        }
    }
}
</style>
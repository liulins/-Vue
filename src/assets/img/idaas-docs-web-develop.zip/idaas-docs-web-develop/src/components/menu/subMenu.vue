<template functional>
    <a-sub-menu :key="props.data.path">
        <span slot="title">
            <a-icon class="icon-box" v-if="props.data.meta.icon" :type="props.data.meta.icon" />
            <span v-if="props.data.meta.type == 'title'">{{props.data.meta.text}}</span>
            <router-link v-else :to="props.data.path">{{ props.data.meta.text }}</router-link>
        </span>
        <template v-for="item in props.data.children">
            <a-menu-item v-if="!item.children" :key="item.path" >
                <router-link :to="item.path"><a-icon class="icon-box" v-if="item.meta.icon" :type="item.meta.icon" />
                    <span>{{item.meta.text}}</span>
                </router-link>
            </a-menu-item>
            <SubMenu :data="item" v-else></SubMenu>
        </template>
    </a-sub-menu>
</template>
<script>
export default {
    data(){
        return{

        }
    },
    mounted(){
        console.log(this.props.data)
    },
    methods:{

    }
}
</script>

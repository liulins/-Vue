<template>
	<div class="menu-box">
		<a-menu
			mode="inline" :style="{width: this.$store.state.collapsed ? '80px':'300px'}"
			v-model="current"
			:inline-collapsed="this.$store.state.collapsed"
			:open-keys="openKeys"
			@openChange="onOpenChange"
            :defaultOpenKeys="defaultOpenKeys">
			
			<template v-for="item in listData">
                <!-- 单级 -->
				<a-menu-item v-if="!item.children" @click="rowFun(item)" :key="item.path">
					<a-icon class="icon-box" :type="item.meta.icon" />
					<router-link :to="item.path" class="link-title">{{ item.meta.text }}</router-link>
				</a-menu-item>
                <SubMenu v-else :data="item"></SubMenu>
			</template>
		</a-menu>
	</div>
</template>

<script>
import menu from '@/router'

import SubMenu from '@/components/menu/subMenu'
export default {
    components: { SubMenu },
	data() {
		return {
			listData: [],
            defaultOpenKeys: [],
			collapsed: this.$store.state.collapsed,
			openKeys:['/account','/userGroup'],
			rootSubmenuKeys: [],
			openKeyChild:['/userManage'],
		}
	},
	created() {
		this.listData = menu.options.routes[0].children
        this.defaultOpenKeys = []
        this.filterKey(this.listData)
		this.setStyle(this.$store.state.collapsed)
	},
	mounted(){
		// this.openKeys = this.listData[0].path
		// console.log(this.defaultOpenKeys)
	},
	computed: {
		current: {
			get() {
				return [this.$route.path]
			},
			set(v) {
			}
		}
	},
	watch: {
		"$store.state.collapsed"(newVal) {
			this.setStyle(newVal)
		}
	},
	methods: {
		onOpenChange(openKeys) {
			let rootSubmenuKeys = [];
			let listData = menu.options.routes[0].children;
			let twoRoot = [];
			let twoList = listData[1].children;
			let threeRoot = [];
			let threeList = twoList[2].children;
			for(let i = 0;i<threeList.length;i++){
				threeRoot.push(threeList[i].path)
			}
			for(let i = 0;i<twoList.length;i++){
				twoRoot.push(twoList[i].path)
			}
			for(let i = 0;i<this.listData.length;i++){
				rootSubmenuKeys.push(listData[i].path)
			}
			const latestOpenKey = openKeys.find(key => this.openKeys.indexOf(key) === -1);
			if (rootSubmenuKeys.indexOf(latestOpenKey) === -1) {  //等于-1代表没有相同的
				if(twoRoot.indexOf(latestOpenKey) != -1){  //不等于-1代表有相同的
					this.openKeys = latestOpenKey ? [latestOpenKey,"/guide"] : [];
				}else if(threeRoot.indexOf(latestOpenKey) != -1){
					this.openKeys = latestOpenKey ? [latestOpenKey,"/guide","/identityAuthentication"] : [];
				}else{
					this.openKeys = openKeys;
				}
			}else {
				this.openKeys = latestOpenKey ? [latestOpenKey] : [];
			}
		},
        filterKey(data) {
            for (let item of data) {
                this.defaultOpenKeys.push(item.path)
                if (item.children) {
                    this.filterKey(item.children)
                }
            }
        },
		rowFun(val) {
			this.$router.push(val.path)
		},
		setStyle(status) {
			if (!status) {
				setTimeout(()=>{
					let doms = document.getElementsByClassName("menu-box")[0].getElementsByClassName("ant-menu-item")
					let doms2 = document.getElementsByClassName("menu-box")[0].getElementsByClassName("ant-menu-submenu-title")
					for (let item of doms) {
						item.getElementsByTagName("a")[0].getElementsByTagName("span")[0].classList.add("white-space-def")
						item.getElementsByTagName("a")[0].getElementsByTagName("span")[0].classList.remove("white-space-act")
					}
					for (let item2 of doms2) {
						item2.classList.add("white-space-def")
						item2.classList.remove("white-space-act")
					}
				}, 0)
			} else {
				setTimeout(()=>{
					let doms = document.getElementsByClassName("menu-box")[0].getElementsByClassName("ant-menu-item")
					let doms2 = document.getElementsByClassName("menu-box")[0].getElementsByClassName("ant-menu-submenu-title")
					for (let item of doms) {
						item.getElementsByTagName("a")[0].getElementsByTagName("span")[0].classList.remove("white-space-def")
						item.getElementsByTagName("a")[0].getElementsByTagName("span")[0].classList.add("white-space-act")
					}
					for (let item2 of doms2) {
						item2.classList.add("white-space-act")
						item2.classList.remove("white-space-def")
					}
				}, 0)
			}
		},
	},
}
</script>

<style scoped lang="scss">
.menu-box ::v-deep {
	background: #FFFFFF;
	padding-top: 40px;
	box-shadow: 0px 0px 5px 1px rgba(0, 0, 0, 0.08);
	position: relative;
	overflow-x: hidden;
	overflow-y: auto;
    // width: 300px;
	.ant-menu {
		color: rgb(15, 15, 15);
		border-right: 0;
	}
	.icon-box {
		font-size: 18px;
	}
	.ant-menu-submenu-title, .ant-menu-item {
        // white-space: pre-line !important;
        line-height: 24px !important;
        height: auto !important;
		padding-top: 8px;
		padding-bottom: 8px;
    }
	.white-space-def {
		white-space: normal;
	}
	.white-space-act {
		white-space: nowrap;
	}
	.ant-menu-item .anticon + .link-title, .ant-menu-submenu-title .anticon + .link-title {
		opacity: 1;
		display: inline-block;
	}
	.ant-menu-inline-collapsed > .ant-menu-item .anticon + .link-title,
	.ant-menu-inline-collapsed > .ant-menu-item-group > .ant-menu-item-group-list > .ant-menu-item .anticon + .link-title,
	.ant-menu-inline-collapsed > .ant-menu-item-group > .ant-menu-item-group-list > .ant-menu-submenu > .ant-menu-submenu-title .anticon + .link-title,
	.ant-menu-inline-collapsed > .ant-menu-submenu > .ant-menu-submenu-title .anticon + .link-title {
		display: inline-block;
		max-width: 0;
		opacity: 0;
	}
}
.ant-menu-item ::v-deep{
	> a{
		color: rgb(19,19,19);
	}
}
.ant-menu-item-selected > a, .ant-menu-item-selected > a:hover ::v-deep{
	color: #1890ff;
}
.ant-menu-vertical .ant-menu-item, .ant-menu-vertical-left .ant-menu-item, .ant-menu-vertical-right .ant-menu-item, .ant-menu-inline .ant-menu-item, .ant-menu-vertical .ant-menu-submenu-title, .ant-menu-vertical-left .ant-menu-submenu-title, .ant-menu-vertical-right .ant-menu-submenu-title, .ant-menu-inline .ant-menu-submenu-title ::v-deep{
    font-size: 15px;
}
</style>
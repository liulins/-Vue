<template id="mianfei">
    <div class="mianfei">
        免费小说
    </div>
</template>
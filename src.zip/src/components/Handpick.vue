<template id="handpick">
    <div class="handpick">
        精选
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
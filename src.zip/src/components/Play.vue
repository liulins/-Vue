<template id="play">
    <div class="play">
        播放
    </div>
</template>
<style>
  /* @import url(../assets/css/app.css); */
</style>
<template id="xinxiu">
    <div class="xinxiu">
        新秀
    </div>
</template>
<style>
  /* @import url(../assets/css/app.css); */
</style>
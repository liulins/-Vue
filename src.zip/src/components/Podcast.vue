<template id="podcast">
    <div class="podcast">
        播客
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
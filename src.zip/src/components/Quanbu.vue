<template id="quanbu">
    <div class="quanbu">
        全部分类
    </div>
</template>
<template id="beijing">
    <div class="beijing">
        北京
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
<template id="vip">
    <div class="vip">
        VIP
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
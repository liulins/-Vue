<template id="ertong">
    <div class="ertong">
        儿童故事
    </div>
</template>
<template id="humanity">
    <div class="humanity">
        人文
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
<template id="xueyingyu">
    <div class="xueyingyu">
        学英语
    </div>
</template>
<template id="melisten">
    <div class="melisten">
        我听
    </div>
</template>
<style>
  /* @import url(../assets/css/app.css); */
</style>
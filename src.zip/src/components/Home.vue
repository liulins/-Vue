<template id="home">
    <div class="home">
        首页
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
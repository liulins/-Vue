<template id="discover">
    <div class="discover">
        发现
    </div>
</template>
<style>
  /* @import url(../assets/css/app.css); */
</style>
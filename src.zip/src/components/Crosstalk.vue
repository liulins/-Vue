<template id="crosstalk">
    <div class="crosstalk">
        相声评书
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
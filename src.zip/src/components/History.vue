<template id="history">
    <div class="history">
        历史
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
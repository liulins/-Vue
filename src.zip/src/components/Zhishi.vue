<template id="zhishi">
    <div class="zhishi">
        <VideoView class="tuijian_video"></VideoView>
    </div>
</template>
<script>
import VideoView from '../components/Video'
export default {
    data() {
        return{}
    },
    components:{
        VideoView
    }
}
</script>
<style>
  @import url(../assets/css/live.css);
</style>
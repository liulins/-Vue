// 直播组件
<template id="live">
    <div>
      <div class="live_tit">
        <router-link to="/homepage/live/tuijian" class="live_box1">
            <img src="src/assets/img/23.png" class="live_box1_img1"/>
            <span class="live_box1_p1">推荐</span>
            <span class="live_box1_span1">|</span>
        </router-link>
        <router-link to="/homepage/live/remen" class="live_box1">
            <img src="src/assets/img/24.png" class="live_box1_img1"/>
            <span class="live_box1_p1">热门</span>
            <span class="live_box1_span1">|</span>
        </router-link>
        <router-link to="/homepage/live/qinggan" class="live_box1">
            <img src="src/assets/img/25.png" class="live_box1_img1"/>
            <span class="live_box1_p1">情感</span>
            <span class="live_box1_span1">|</span>
        </router-link>
        <router-link to="/homepage/live/yousheng" class="live_box1">
            <img src="src/assets/img/26.png" class="live_box1_img1"/>
            <span class="live_box1_p1" style="margin-left:2.1rem">有声书</span>
            <span class="live_box1_span1">|</span>
        </router-link>
        <router-link to="/homepage/live/yinyue" class="live_box1">
            <img src="src/assets/img/27.png" class="live_box1_img1"/>
            <span class="live_box1_p1">音乐</span>
            <span class="live_box1_span1">|</span>
        </router-link>
        <router-link to="/homepage/live/liaotian" class="live_box1">
            <img src="src/assets/img/28.png" class="live_box1_img1"/>
            <span class="live_box1_p1" style="margin-left:2.1rem">聊天室</span>
            <span class="live_box1_span1">|</span>
        </router-link>
        <router-link to="/homepage/live/shipin" class="live_box1">
            <img src="src/assets/img/29.png" class="live_box1_img1"/>
            <span class="live_box1_p1">视频</span>
            <span class="live_box1_span1">|</span>
        </router-link>
        <router-link to="/homepage/live/zhishi" class="live_box1">
            <img src="src/assets/img/30.png" class="live_box1_img1"/>
            <span class="live_box1_p1">知识</span>
            <span class="live_box1_span1">|</span>
        </router-link>
        <router-link to="/homepage/live/yule" class="live_box1">
            <img src="src/assets/img/31.png" class="live_box1_img1"/>
            <span class="live_box1_p1">娱乐</span>
            <span class="live_box1_span1">|</span>
        </router-link>
        <router-link to="/homepage/live/xinxiu" class="live_box1">
            <img src="src/assets/img/32.png" class="live_box1_img1"/>
            <span class="live_box1_p1">新秀</span>
        </router-link>
        <!-- 右侧栏我的 -->
        <div class="live_box1_right">
          <img src="src/assets/img/33.png"/>
          <span class="live_box1_right_1">我的</span>
        </div>
      </div>
      <div>
        <router-view></router-view>
      </div>
    </div>
</template>
<style>
  @import url(../assets/css/live.css);
</style>
<template id="suibian">
    <div class="suibian">
        随便听
    </div>
</template>
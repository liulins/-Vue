<template id="tingyinyue">
    <div class="tingyinyue">
        听音乐
    </div>
</template>
<template id="ruzhan">
<!-- 入站必听 -->
    <div class="ruzhan" @scroll="handleScroll($event)">
        <div class="ruzhan_top">
            <img src="src/assets/img/36.jpg" class="ruzhan_top_bg"/>
            <div class="ruzhan_top_bgs"></div>
        </div>
        <!-- 循环数组盒子 -->
        <div class="ruzhan_top_box1" v-for="(k,index) in arrList4" :key="index">
            <p class="ruzhan_top_box1_p1">
                <img src="src/assets/img/37.png" class="ruzhan_top_box1_p1_img1"/>
                <span class="ruzhan_top_box1_p1_span">{{k.tit}}</span>
                <a href="##" class="ruzhan_top_box1_p1_a">
                    更多  >
                </a>
            </p>
            <div class="ruzhan_top_box1_1">
                <img :src="k.img1" class="ruzhan_top_box1_1_img"/>
                <p class="ruzhan_top_box1_1_p">
                    {{k.txt1}}
                </p>
            </div>
            <div class="ruzhan_top_box1_1">
                <img :src="k.img2" class="ruzhan_top_box1_1_img"/>
                <p class="ruzhan_top_box1_1_p">
                    {{k.txt2}}
                </p>
            </div>
            <div class="ruzhan_top_box1_1">
                <img :src="k.img3" class="ruzhan_top_box1_1_img"/>
                <p class="ruzhan_top_box1_1_p">
                    {{k.txt3}}
                </p>
            </div>
        </div>
        <!-- 顶部导航 -->
        <div class="ruzhan_top_nav">
            <img src="src/assets/img/38.png" class="ruzhan_top_nav_img1" @click="back"/>
            <img src="src/assets/img/39.png" class="ruzhan_top_nav_img2"/>
        </div>
        <!-- 底部导航 -->
        <div class="ruzhan_bottom_nav">
            <span class="ruzhan_bottom_nav_box">
                <img src="src/assets/img/40.png" class="ruzhan_bottom_nav_box1"/>
            </span>
        </div>
    </div>
</template>
<style>
@import url(../assets/css/recommend.css);
</style>
<script>
$(function(){
    // $(".ruzhan").on("scroll",function(){
    //     // var topp = $(".ruzhan").scrollTop();
    //     // console.log(topp);
    //     // if(topp>10){
    //     //     alert(1)
    //     // }
    //     alert(1)
    // })
    // var ruZhan = document.getElementById("ruzhan");
    // ruZhan.onscroll = function(){
    //     alert(1)
    // }
})
import {Test1} from '../request/api.js'
export default {
    data(){
        return{
            arrList4:[]
        }
    },
    mounted() {
        this.getData()
    },
    methods: {
        // 获取数据
        getData(){
            var _this = this;
            Test1().then(function(res){
                _this.arrList4 = res.data.ruzhanList1
                // console.log(_this.arrList1)
            })
        },
        // 滚动条事件
        handleScroll(e){
            console.log(1)
        },
        // 返回上一级
        back(){
            this.$router.go(-1)
        }
    },
}
</script>
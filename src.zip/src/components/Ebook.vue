<template id="ebook">
    <div class="ebook">
        电子书
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
<template id="broadcast">
    <div class="broadcast">
        广播
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
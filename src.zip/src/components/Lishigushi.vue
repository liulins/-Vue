<template id="lishigushi">
    <div class="lishigushi">
        历史故事
    </div>
</template>
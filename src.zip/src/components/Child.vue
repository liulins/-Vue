<template id="child">
    <div class="child">
        儿童
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
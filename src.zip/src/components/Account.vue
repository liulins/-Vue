<template id="account">
    <div class="account">
        账号
    </div>
</template>
<style>
  /* @import url(../assets/css/app.css); */
</style>
<template id="novel">
    <div class="novel">
        小说
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>
<template id="bestsellers">
    <div class="bestsellers">
        畅销书
    </div>
</template>
<style>
  @import url(../assets/css/app.css);
</style>